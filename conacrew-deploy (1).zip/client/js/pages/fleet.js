import { el, clear, fmtMoney, fmtDate, fmtDateTime, badge, badgeAs, toast, openModal } from '../dom.js';
import { api } from '../api.js';

const COST_CATEGORIES = ['fuel', 'driver', 'toll', 'maintenance', 'mechanical_repair', 'other'];

function loadForm(drivers, trucks, onSubmit) {
  const driverSel = el('select', { required: true }, [
    el('option', { value: '' }, 'Select driver'),
    ...drivers.map((d) => el('option', { value: d.id }, d.name)),
  ]);
  const truckSel = el('select', {}, [
    el('option', { value: '' }, 'Unassigned'),
    ...trucks.map((t) => el('option', { value: t.id }, t.plate_no)),
  ]);
  const origin = el('input', { required: true, placeholder: 'e.g. Jinja' });
  const destination = el('input', { required: true, placeholder: 'e.g. Kampala' });
  const cargo = el('input', { placeholder: 'e.g. Sugar, 30 tonnes' });
  const rate = el('input', { type: 'number', step: '0.01', placeholder: 'UGX' });
  const dateInput = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
  const errorBox = el('div', { class: 'error-text' });

  const form = el('form', {
    onsubmit: async (e) => {
      e.preventDefault();
      errorBox.textContent = '';
      try {
        await onSubmit({
          driver_id: Number(driverSel.value),
          truck_id: truckSel.value ? Number(truckSel.value) : null,
          origin: origin.value, destination: destination.value, cargo: cargo.value || null,
          rate: rate.value ? Number(rate.value) : null,
          load_date: dateInput.value,
        });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'New load'),
    el('div', { class: 'field' }, [el('label', {}, 'Driver'), driverSel]),
    el('div', { class: 'field' }, [el('label', {}, 'Truck'), truckSel]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Origin'), origin]),
      el('div', { class: 'field' }, [el('label', {}, 'Destination'), destination]),
    ]),
    el('div', { class: 'field' }, [el('label', {}, 'Cargo'), cargo]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Rate (UGX)'), rate]),
      el('div', { class: 'field' }, [el('label', {}, 'Date'), dateInput]),
    ]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Create load')]),
  ]);
  return form;
}

async function renderLoadsTab(container) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const [loadsRes, driversRes, trucksRes] = await Promise.all([
    api.get('/api/fleet/loads'), api.get('/api/drivers'), api.get('/api/fleet/trucks'),
  ]);
  clear(container);

  const newBtn = el('button', {
    class: 'btn btn-accent btn-sm',
    onclick: () => {
      const form = loadForm(driversRes.drivers, trucksRes.trucks, async (payload) => {
        await api.post('/api/fleet/loads', payload);
        close();
        toast('Load created', 'success');
        renderLoadsTab(container);
      });
      const close = openModal(form);
    },
  }, '+ New load');

  container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } }, newBtn));

  const rows = loadsRes.loads.map((l) => el('tr', {}, [
    el('td', {}, fmtDate(l.load_date)),
    el('td', {}, l.driver_name || '—'),
    el('td', {}, l.plate_no || '—'),
    el('td', {}, `${l.origin} → ${l.destination}`),
    el('td', {}, l.cargo || '—'),
    el('td', { class: 'mono' }, l.rate ? fmtMoney(l.rate) : '—'),
    el('td', {}, l.self_sourced ? 'Driver' : 'Dispatch'),
    el('td', {}, badge(l.status)),
    el('td', {}, el('select', {
      value: l.status,
      onchange: async (e) => {
        await api.patch(`/api/fleet/loads/${l.id}`, { status: e.target.value });
        toast('Status updated', 'success');
      },
    }, ['assigned', 'in_transit', 'delivered', 'cancelled'].map((s) => el('option', { value: s, selected: s === l.status }, s)))),
  ]));

  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Driver', 'Truck', 'Route', 'Cargo', 'Rate', 'Source', 'Status', ''].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 9 }, 'No loads yet.'))),
  ]))));
}

async function renderIssuesTab(container) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const { issues } = await api.get('/api/fleet/issues');
  clear(container);
  const rows = issues.map((i) => el('tr', {}, [
    el('td', {}, fmtDateTime(i.created_at)),
    el('td', {}, i.driver_name || '—'),
    el('td', {}, i.plate_no || '—'),
    el('td', {}, i.kind === 'voice'
      ? el('a', { href: `/api/fleet/issues/${i.id}/voice`, target: '_blank' }, `▶ Voice note (${Math.round(i.voice_seconds || 0)}s)`)
      : (i.message || '—')),
    el('td', {}, badge(i.status)),
    el('td', {}, i.status === 'open'
      ? el('button', {
          class: 'btn btn-ghost btn-sm',
          onclick: async (e) => { await api.patch(`/api/fleet/issues/${i.id}`, { status: 'resolved' }); toast('Marked resolved', 'success'); renderIssuesTab(container); },
        }, 'Mark resolved')
      : '—'),
  ]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Reported', 'Driver', 'Truck', 'Issue', 'Status', ''].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 6 }, 'No issues reported.'))),
  ]))));
}

async function renderExpenseRequestsTab(container) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const { requests } = await api.get('/api/fleet/expense-requests');
  clear(container);
  const rows = requests.map((r) => el('tr', {}, [
    el('td', {}, fmtDate(r.created_at)),
    el('td', {}, r.submitted_by_name || '—'),
    el('td', {}, r.plate_no || '—'),
    el('td', {}, r.category.replace(/_/g, ' ')),
    el('td', { class: 'mono' }, fmtMoney(r.amount)),
    el('td', {}, r.description || '—'),
    el('td', {}, badge(r.status)),
    el('td', {}, r.status === 'pending' ? el('div', { style: { display: 'flex', gap: '6px' } }, [
      el('button', {
        class: 'btn btn-accent btn-sm',
        onclick: async () => { await api.patch(`/api/fleet/expense-requests/${r.id}`, { status: 'accepted' }); toast('Accepted', 'success'); renderExpenseRequestsTab(container); },
      }, 'Accept'),
      el('button', {
        class: 'btn btn-danger btn-sm',
        onclick: async () => { await api.patch(`/api/fleet/expense-requests/${r.id}`, { status: 'declined' }); toast('Declined'); renderExpenseRequestsTab(container); },
      }, 'Decline'),
    ]) : '—'),
  ]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Driver', 'Truck', 'Category', 'Amount', 'Notes', 'Status', ''].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 8 }, 'No expense requests.'))),
  ]))));
}

async function renderTrucksTab(container) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const [{ trucks }, { drivers }] = await Promise.all([api.get('/api/fleet/trucks'), api.get('/api/drivers')]);
  clear(container);

  const plateInput = el('input', { placeholder: 'Plate number', required: true });
  const driverSel = el('select', {}, [el('option', { value: '' }, 'Unassigned'), ...drivers.map((d) => el('option', { value: d.id }, d.name))]);
  const addForm = el('form', {
    class: 'form-row',
    style: { alignItems: 'flex-end', marginBottom: '16px' },
    onsubmit: async (e) => {
      e.preventDefault();
      await api.post('/api/fleet/trucks', { plate_no: plateInput.value, driver_id: driverSel.value ? Number(driverSel.value) : null });
      toast('Truck added', 'success');
      renderTrucksTab(container);
    },
  }, [
    el('div', { class: 'field' }, [el('label', {}, 'Plate no.'), plateInput]),
    el('div', { class: 'field' }, [el('label', {}, 'Driver'), driverSel]),
    el('button', { class: 'btn btn-accent', type: 'submit' }, 'Add truck'),
  ]);

  const rows = trucks.map((t) => el('tr', {}, [el('td', {}, t.plate_no), el('td', {}, t.driver_name || '—'), el('td', {}, t.active ? badgeAs('resolved', 'Active') : badgeAs('declined', 'Inactive'))]));
  container.appendChild(el('div', { class: 'card' }, [
    addForm,
    el('div', { class: 'table-wrap' }, el('table', {}, [
      el('thead', {}, el('tr', {}, ['Plate no.', 'Driver', 'Active'].map((h) => el('th', {}, h)))),
      el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 3 }, 'No trucks yet.'))),
    ])),
  ]));
}

export async function renderFleet(content, user) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, 'Fleet'), el('p', {}, 'Loads, issue reports, expense approvals, and trucks.')]),
  ]));

  const tabsDef = [
    ['loads', 'Loads', renderLoadsTab],
    ['issues', 'Issues', renderIssuesTab],
    ['expenses', 'Expense requests', renderExpenseRequestsTab],
    ['trucks', 'Trucks', renderTrucksTab],
  ];
  const body = el('div', {});
  const tabsBar = el('div', { class: 'tabs' });

  function activate(key) {
    tabsBar.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.key === key));
    const entry = tabsDef.find(([k]) => k === key);
    entry[2](body);
  }
  tabsDef.forEach(([key, label]) => {
    tabsBar.appendChild(el('div', { class: 'tab', 'data-key': key, onclick: () => activate(key) }, label));
  });

  content.appendChild(tabsBar);
  content.appendChild(body);
  activate('loads');
}
