import fs from 'node:fs';
import { db, postLedgerEntry } from '../db.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth, requireRole, ROLES } from '../context.js';
import { saveBase64File } from '../files.js';

const CAN_SEE_ALL_FLEET = [ROLES.ADMIN, ROLES.DISPATCHER];

export function registerFleetRoutes(router) {
  // ---- Trucks ----
  router.get('/api/fleet/trucks', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const trucks = db.prepare(`SELECT t.id, t.plate_no, t.active, t.driver_id, u.name as driver_name
      FROM fleet_trucks t LEFT JOIN users u ON u.id = t.driver_id ORDER BY t.plate_no`).all();
    sendJson(res, 200, { trucks });
  });

  router.post('/api/fleet/trucks', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, CAN_SEE_ALL_FLEET, res, sendError)) return;
    const { plate_no, driver_id } = body || {};
    if (!plate_no) return sendError(res, 400, 'plate_no is required');
    try {
      const info = db.prepare('INSERT INTO fleet_trucks (plate_no, driver_id) VALUES (?,?)').run(plate_no, driver_id || null);
      sendJson(res, 201, { id: info.lastInsertRowid });
    } catch (e) {
      sendError(res, 400, e.message.includes('UNIQUE') ? 'Plate number already exists' : e.message);
    }
  });

  // ---- Loads ----
  router.get('/api/fleet/loads', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    let rows;
    if (CAN_SEE_ALL_FLEET.includes(user.role)) {
      rows = db.prepare(`SELECT l.*, u.name as driver_name, t.plate_no
        FROM fleet_loads l LEFT JOIN users u ON u.id = l.driver_id
        LEFT JOIN fleet_trucks t ON t.id = l.truck_id
        ORDER BY l.created_at DESC`).all();
    } else if (user.role === ROLES.DRIVER) {
      rows = db.prepare(`SELECT l.*, u.name as driver_name, t.plate_no
        FROM fleet_loads l LEFT JOIN users u ON u.id = l.driver_id
        LEFT JOIN fleet_trucks t ON t.id = l.truck_id
        WHERE l.driver_id = ? ORDER BY l.created_at DESC`).all(user.id);
    } else {
      return sendError(res, 403, 'Not permitted');
    }
    sendJson(res, 200, { loads: rows });
  });

  router.post('/api/fleet/loads', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!CAN_SEE_ALL_FLEET.includes(user.role) && user.role !== ROLES.DRIVER) {
      return sendError(res, 403, 'Not permitted');
    }
    const { truck_id, driver_id, origin, destination, cargo, rate, load_date, notes } = body || {};
    let finalDriverId = driver_id;
    let selfSourced = 0;
    let createdBy = user.id;
    if (user.role === ROLES.DRIVER) {
      finalDriverId = user.id; // drivers can only create their own loads
      selfSourced = 1;
    }
    if (!finalDriverId) return sendError(res, 400, 'driver_id is required');
    if (!origin || !destination) return sendError(res, 400, 'origin and destination are required');
    const info = db.prepare(`INSERT INTO fleet_loads
      (truck_id, driver_id, created_by, self_sourced, origin, destination, cargo, rate, load_date, notes)
      VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
      truck_id || null, finalDriverId, createdBy, selfSourced, origin, destination, cargo || null,
      rate ?? null, load_date || new Date().toISOString(), notes || null
    );
    if (rate) {
      postLedgerEntry({
        venture: 'fleet', entry_type: 'revenue', category: selfSourced ? 'self_sourced_load' : 'dispatched_load',
        amount: rate, entry_date: load_date || new Date().toISOString(),
        source_table: 'fleet_loads', source_id: info.lastInsertRowid, created_by: user.id,
        notes: `${origin} -> ${destination}`,
      });
    }
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  router.patch('/api/fleet/loads/:id', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const load = db.prepare('SELECT * FROM fleet_loads WHERE id = ?').get(params.id);
    if (!load) return sendError(res, 404, 'Load not found');
    const isOwnerDriver = user.role === ROLES.DRIVER && load.driver_id === user.id;
    if (!CAN_SEE_ALL_FLEET.includes(user.role) && !isOwnerDriver) return sendError(res, 403, 'Not permitted');
    const fields = [];
    const values = [];
    if (body.status) { fields.push('status = ?'); values.push(body.status); }
    if (body.truck_id !== undefined && !isOwnerDriver) { fields.push('truck_id = ?'); values.push(body.truck_id); }
    if (body.notes !== undefined) { fields.push('notes = ?'); values.push(body.notes); }
    if (!fields.length) return sendError(res, 400, 'Nothing to update');
    values.push(params.id);
    db.prepare(`UPDATE fleet_loads SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    sendJson(res, 200, { ok: true });
  });

  // ---- Load costs (dispatch/admin only) ----
  router.post('/api/fleet/loads/:id/costs', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, CAN_SEE_ALL_FLEET, res, sendError)) return;
    const load = db.prepare('SELECT * FROM fleet_loads WHERE id = ?').get(params.id);
    if (!load) return sendError(res, 404, 'Load not found');
    const { category, amount, note, cost_date } = body || {};
    if (!category || !amount) return sendError(res, 400, 'category and amount are required');
    const info = db.prepare(`INSERT INTO fleet_load_costs (load_id, category, amount, note, cost_date, created_by)
      VALUES (?,?,?,?,?,?)`).run(params.id, category, amount, note || null, cost_date || new Date().toISOString(), user.id);
    postLedgerEntry({
      venture: 'fleet', entry_type: 'expense', category, amount,
      entry_date: cost_date || new Date().toISOString(), source_table: 'fleet_load_costs',
      source_id: info.lastInsertRowid, created_by: user.id, notes: note || `Load #${params.id}`,
    });
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  router.get('/api/fleet/loads/:id/costs', async (req, res, params) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, CAN_SEE_ALL_FLEET, res, sendError)) return;
    const costs = db.prepare('SELECT * FROM fleet_load_costs WHERE load_id = ? ORDER BY cost_date DESC').all(params.id);
    sendJson(res, 200, { costs });
  });

  // ---- Issue reports (text or voice note <=3min) ----
  router.get('/api/fleet/issues', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    let rows;
    if (CAN_SEE_ALL_FLEET.includes(user.role)) {
      rows = db.prepare(`SELECT i.*, u.name as driver_name, t.plate_no FROM fleet_issues i
        LEFT JOIN users u ON u.id = i.driver_id LEFT JOIN fleet_trucks t ON t.id = i.truck_id
        ORDER BY i.created_at DESC`).all();
    } else if (user.role === ROLES.DRIVER) {
      rows = db.prepare(`SELECT i.*, u.name as driver_name, t.plate_no FROM fleet_issues i
        LEFT JOIN users u ON u.id = i.driver_id LEFT JOIN fleet_trucks t ON t.id = i.truck_id
        WHERE i.driver_id = ? ORDER BY i.created_at DESC`).all(user.id);
    } else {
      return sendError(res, 403, 'Not permitted');
    }
    sendJson(res, 200, { issues: rows });
  });

  router.post('/api/fleet/issues', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.DRIVER], res, sendError)) return;
    const { kind, message, truck_id, voice_base64, voice_seconds, mime_type } = body || {};
    if (kind === 'text') {
      if (!message || !message.trim()) return sendError(res, 400, 'message is required for a text issue');
      const info = db.prepare(`INSERT INTO fleet_issues (driver_id, truck_id, kind, message) VALUES (?,?,?,?)`)
        .run(user.id, truck_id || null, 'text', message.trim());
      return sendJson(res, 201, { id: info.lastInsertRowid });
    } else if (kind === 'voice') {
      if (!voice_base64) return sendError(res, 400, 'voice_base64 is required for a voice issue');
      if (voice_seconds && voice_seconds > 180) return sendError(res, 400, 'Voice note must be under 3 minutes');
      const filePath = saveBase64File('voice', voice_base64, mime_type || 'audio/webm');
      const info = db.prepare(`INSERT INTO fleet_issues (driver_id, truck_id, kind, voice_path, voice_seconds) VALUES (?,?,?,?,?)`)
        .run(user.id, truck_id || null, 'voice', filePath, voice_seconds || null);
      return sendJson(res, 201, { id: info.lastInsertRowid });
    }
    sendError(res, 400, "kind must be 'text' or 'voice'");
  });

  router.patch('/api/fleet/issues/:id', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, CAN_SEE_ALL_FLEET, res, sendError)) return;
    if (body.status !== 'resolved' && body.status !== 'open') return sendError(res, 400, 'Invalid status');
    db.prepare(`UPDATE fleet_issues SET status = ?, resolved_at = CASE WHEN ? = 'resolved' THEN datetime('now') ELSE NULL END, resolved_by = ? WHERE id = ?`)
      .run(body.status, body.status, user.id, params.id);
    sendJson(res, 200, { ok: true });
  });

  router.get('/api/fleet/issues/:id/voice', async (req, res, params) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const issue = db.prepare('SELECT * FROM fleet_issues WHERE id = ?').get(params.id);
    if (!issue || !issue.voice_path) return sendError(res, 404, 'Not found');
    const isOwner = user.role === ROLES.DRIVER && issue.driver_id === user.id;
    if (!CAN_SEE_ALL_FLEET.includes(user.role) && !isOwner) return sendError(res, 403, 'Not permitted');
    res.writeHead(200, { 'Content-Type': 'audio/webm', 'Access-Control-Allow-Origin': '*' });
    res.end(fs.readFileSync(issue.voice_path));
  });

  // ---- Expense requests (driver submits -> admin/dispatch accepts -> driver settles) ----
  router.get('/api/fleet/expense-requests', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    let rows;
    if (CAN_SEE_ALL_FLEET.includes(user.role)) {
      rows = db.prepare(`SELECT e.*, u.name as submitted_by_name, t.plate_no FROM expense_requests e
        LEFT JOIN users u ON u.id = e.submitted_by LEFT JOIN fleet_trucks t ON t.id = e.truck_id
        ORDER BY e.created_at DESC`).all();
    } else if (user.role === ROLES.DRIVER) {
      rows = db.prepare(`SELECT e.*, u.name as submitted_by_name, t.plate_no FROM expense_requests e
        LEFT JOIN users u ON u.id = e.submitted_by LEFT JOIN fleet_trucks t ON t.id = e.truck_id
        WHERE e.submitted_by = ? ORDER BY e.created_at DESC`).all(user.id);
    } else {
      return sendError(res, 403, 'Not permitted');
    }
    sendJson(res, 200, { requests: rows });
  });

  router.post('/api/fleet/expense-requests', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.DRIVER], res, sendError)) return;
    const { category, amount, description, truck_id } = body || {};
    if (!category || !amount) return sendError(res, 400, 'category and amount are required');
    const info = db.prepare(`INSERT INTO expense_requests (submitted_by, venture, category, amount, description, truck_id)
      VALUES (?, 'fleet', ?, ?, ?, ?)`).run(user.id, category, amount, description || null, truck_id || null);
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  router.patch('/api/fleet/expense-requests/:id', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const reqRow = db.prepare('SELECT * FROM expense_requests WHERE id = ?').get(params.id);
    if (!reqRow) return sendError(res, 404, 'Not found');
    const { status } = body || {};
    if (['accepted', 'declined'].includes(status)) {
      if (!requireRole(user, CAN_SEE_ALL_FLEET, res, sendError)) return;
      if (reqRow.status !== 'pending') return sendError(res, 400, 'Only a pending request can be accepted/declined');
      db.prepare(`UPDATE expense_requests SET status = ?, decided_by = ?, decided_at = datetime('now') WHERE id = ?`)
        .run(status, user.id, params.id);
      return sendJson(res, 200, { ok: true });
    }
    if (status === 'settled') {
      const isOwnerDriver = user.role === ROLES.DRIVER && reqRow.submitted_by === user.id;
      if (!isOwnerDriver && !CAN_SEE_ALL_FLEET.includes(user.role)) return sendError(res, 403, 'Not permitted');
      if (reqRow.status !== 'accepted') return sendError(res, 400, 'Only an accepted request can be settled');
      db.prepare(`UPDATE expense_requests SET status = 'settled', settled_at = datetime('now') WHERE id = ?`).run(params.id);
      postLedgerEntry({
        venture: 'fleet', entry_type: 'expense', category: reqRow.category, amount: reqRow.amount,
        source_table: 'expense_requests', source_id: reqRow.id, created_by: user.id,
        notes: reqRow.description || `Expense request #${reqRow.id}`,
      });
      return sendJson(res, 200, { ok: true });
    }
    sendError(res, 400, 'Invalid status transition');
  });
}
