#!/usr/bin/env bash
# One-time setup for running Conacrew on a fresh Hostinger VPS (Ubuntu 22.04/24.04).
# Run this as root, once, via the VPS's browser terminal in hPanel.
#
# What it does:
#   - Installs Node.js 22, nginx, certbot, pm2
#   - Points the app's database/uploads storage at /opt/conacrew-data,
#     OUTSIDE the git-cloned code folder, so future updates never touch your data
#   - Starts the app with pm2 (auto-restarts on crash and on server reboot)
#   - Configures nginx as a reverse proxy for your domain, with free HTTPS via certbot
#
# Safe to re-run: it will not overwrite existing data or duplicate the pm2 process.

set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

APP_DIR="/opt/conacrew"
DATA_DIR="/opt/conacrew-data/db"
UPLOADS_DIR="/opt/conacrew-data/uploads"
DOMAIN="conacrewlogs.com"
APP_PORT=3000

echo "== Updating package lists =="
apt-get update -y

echo "== Installing Node.js 22 =="
if ! command -v node >/dev/null 2>&1 || [ "$(node -v | sed 's/v//' | cut -d. -f1)" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
node -v

echo "== Installing nginx, certbot, git =="
apt-get install -y nginx git certbot python3-certbot-nginx

echo "== Installing pm2 =="
npm install -g pm2

echo "== Setting up persistent data directories =="
mkdir -p "$DATA_DIR" "$UPLOADS_DIR"

echo "== Writing environment file (generates a fresh auth secret on first run) =="
ENV_FILE="$APP_DIR/server/.env"
if [ ! -f "$ENV_FILE" ]; then
  AUTH_SECRET="$(openssl rand -hex 32)"
  cat > "$ENV_FILE" <<EOF
PORT=${APP_PORT}
DATA_DIR=${DATA_DIR}
UPLOADS_DIR=${UPLOADS_DIR}
AUTH_SECRET=${AUTH_SECRET}
EOF
  echo "Created $ENV_FILE"
else
  echo "$ENV_FILE already exists, leaving it as-is"
fi

echo "== Installing app dependencies (none expected — this app has zero external packages) =="
cd "$APP_DIR/server"
npm install --omit=dev || true

echo "== Seeding initial accounts (safe to re-run — skips users that already exist) =="
node --env-file=.env src/seed.js

echo "== Starting app with pm2 =="
pm2 delete conacrew >/dev/null 2>&1 || true
pm2 start src/server.js --name conacrew --cwd "$APP_DIR/server" --node-args="--env-file=.env"
pm2 save
STARTUP_CMD="$(pm2 startup systemd -u root --hp /root | tail -n 1)"
eval "$STARTUP_CMD" || true

echo "== Configuring nginx reverse proxy for ${DOMAIN} =="
cat > /etc/nginx/sites-available/conacrew <<NGINX
server {
    listen 80;
    server_name ${DOMAIN} www.${DOMAIN};

    location / {
        proxy_pass http://127.0.0.1:${APP_PORT};
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
NGINX
ln -sf /etc/nginx/sites-available/conacrew /etc/nginx/sites-enabled/conacrew
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

if command -v ufw >/dev/null 2>&1; then
  echo "== Opening firewall for SSH + HTTP/HTTPS =="
  ufw allow OpenSSH || true
  ufw allow 'Nginx Full' || true
fi

echo "== Requesting free SSL certificate for ${DOMAIN} =="
if certbot --nginx -d "${DOMAIN}" -d "www.${DOMAIN}" --non-interactive --agree-tos -m "admin@${DOMAIN}" --redirect; then
  echo ""
  echo "Done. Your app is live at: https://${DOMAIN}"
else
  echo ""
  echo "Certbot could not issue a certificate yet — this almost always means"
  echo "${DOMAIN}'s DNS A record isn't pointed at this server's IP yet (or hasn't propagated)."
  echo "The app is already running at: http://${DOMAIN} (once DNS is pointed here)"
  echo "or right now at: http://$(curl -s ifconfig.me):${APP_PORT}"
  echo "Once DNS is correct, re-run:"
  echo "  certbot --nginx -d ${DOMAIN} -d www.${DOMAIN}"
fi

echo ""
pm2 status
