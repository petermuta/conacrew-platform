import { verifyToken } from './auth.js';
import { db } from './db.js';

// Returns the authenticated user (fresh from DB) or null.
export function getUser(req) {
  const header = req.headers['authorization'] || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  const payload = verifyToken(token);
  if (!payload || !payload.id) return null;
  const user = db.prepare('SELECT id, name, email, role, operation_id, active FROM users WHERE id = ?').get(payload.id);
  if (!user || !user.active) return null;
  return user;
}

export function requireAuth(req, res, sendError) {
  const user = getUser(req);
  if (!user) {
    sendError(res, 401, 'Not authenticated');
    return null;
  }
  return user;
}

export function requireRole(user, roles, res, sendError) {
  if (!roles.includes(user.role)) {
    sendError(res, 403, 'Not permitted for this role');
    return false;
  }
  return true;
}

export const ROLES = {
  ADMIN: 'admin',
  DISPATCHER: 'dispatcher',
  SUGARCANE_MANAGER: 'sugarcane_manager',
  PASSION_FRUIT_MANAGER: 'passion_fruit_manager',
  DRIVER: 'driver',
};
