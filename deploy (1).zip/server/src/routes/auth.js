import { db } from '../db.js';
import { verifyPassword, signToken, hashPassword } from '../auth.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth } from '../context.js';

export function registerAuthRoutes(router) {
  router.post('/api/auth/login', async (req, res, params, body) => {
    const { email, password } = body || {};
    if (!email || !password) return sendError(res, 400, 'Email and password are required');
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).toLowerCase().trim());
    if (!user || !user.active || !verifyPassword(password, user.password_hash)) {
      return sendError(res, 401, 'Invalid email or password');
    }
    const token = signToken({ id: user.id, role: user.role });
    sendJson(res, 200, {
      token,
      user: {
        id: user.id, name: user.name, email: user.email, role: user.role, operation_id: user.operation_id,
      },
    });
  });

  router.get('/api/auth/me', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    sendJson(res, 200, { user });
  });

  router.post('/api/auth/change-password', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const { current_password, new_password } = body || {};
    if (!current_password || !new_password || new_password.length < 8) {
      return sendError(res, 400, 'Current password and a new password (8+ chars) are required');
    }
    const full = db.prepare('SELECT * FROM users WHERE id = ?').get(user.id);
    if (!verifyPassword(current_password, full.password_hash)) {
      return sendError(res, 401, 'Current password is incorrect');
    }
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(new_password), user.id);
    sendJson(res, 200, { ok: true });
  });
}
