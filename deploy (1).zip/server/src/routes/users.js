import { db } from '../db.js';
import { hashPassword } from '../auth.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth, requireRole, ROLES } from '../context.js';

export function registerUserRoutes(router) {
  // Admin: list all users (for the Users management screen)
  router.get('/api/users', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.ADMIN], res, sendError)) return;
    const users = db.prepare(`SELECT u.id, u.name, u.email, u.role, u.operation_id, u.active, u.created_at,
      so.name as operation_name
      FROM users u LEFT JOIN sugarcane_operations so ON so.id = u.operation_id
      ORDER BY u.role, u.name`).all();
    sendJson(res, 200, { users });
  });

  router.post('/api/users', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.ADMIN], res, sendError)) return;
    const { name, email, password, role, operation_id } = body || {};
    if (!name || !email || !password || !role) return sendError(res, 400, 'name, email, password, role are required');
    const validRoles = ['admin', 'dispatcher', 'sugarcane_manager', 'passion_fruit_manager', 'driver'];
    if (!validRoles.includes(role)) return sendError(res, 400, 'Invalid role');
    if (role === 'sugarcane_manager' && !operation_id) {
      return sendError(res, 400, 'operation_id is required for a sugarcane manager');
    }
    try {
      const info = db.prepare(
        'INSERT INTO users (name, email, password_hash, role, operation_id) VALUES (?,?,?,?,?)'
      ).run(name, String(email).toLowerCase().trim(), hashPassword(password), role, role === 'sugarcane_manager' ? operation_id : null);
      sendJson(res, 201, { id: info.lastInsertRowid });
    } catch (e) {
      sendError(res, 400, e.message.includes('UNIQUE') ? 'Email already in use' : e.message);
    }
  });

  router.patch('/api/users/:id', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.ADMIN], res, sendError)) return;
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(params.id);
    if (!target) return sendError(res, 404, 'User not found');
    const fields = [];
    const values = [];
    if (typeof body.active === 'boolean') { fields.push('active = ?'); values.push(body.active ? 1 : 0); }
    if (body.name) { fields.push('name = ?'); values.push(body.name); }
    if (body.password) { fields.push('password_hash = ?'); values.push(hashPassword(body.password)); }
    if (!fields.length) return sendError(res, 400, 'Nothing to update');
    values.push(params.id);
    db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    sendJson(res, 200, { ok: true });
  });

  // Everyone can see the driver list (dispatch needs it to assign loads); scoped lightly.
  router.get('/api/drivers', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.ADMIN, ROLES.DISPATCHER], res, sendError)) return;
    const drivers = db.prepare("SELECT id, name, email FROM users WHERE role = 'driver' AND active = 1 ORDER BY name").all();
    sendJson(res, 200, { drivers });
  });

  router.get('/api/sugarcane/operations', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const ops = db.prepare('SELECT id, name FROM sugarcane_operations ORDER BY name').all();
    sendJson(res, 200, { operations: ops });
  });
}
