import { db, postLedgerEntry } from '../db.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth, requireRole, ROLES } from '../context.js';

const CAN_SEE_LEDGER = [ROLES.ADMIN, ROLES.DISPATCHER];

export function registerLedgerRoutes(router) {
  // Full transaction list, optionally filtered by venture / date range via query string.
  router.get('/api/ledger/transactions', async (req, res, params, body, query) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, CAN_SEE_LEDGER, res, sendError)) return;
    let sql = `SELECT t.*, u.name as created_by_name, o.name as operation_name FROM ledger_transactions t
      LEFT JOIN users u ON u.id = t.created_by
      LEFT JOIN sugarcane_operations o ON o.id = t.operation_id WHERE 1=1`;
    const args = [];
    if (query.venture) { sql += ' AND t.venture = ?'; args.push(query.venture); }
    if (query.from) { sql += ' AND t.entry_date >= ?'; args.push(query.from); }
    if (query.to) { sql += ' AND t.entry_date <= ?'; args.push(query.to); }
    sql += ' ORDER BY t.entry_date DESC LIMIT 500';
    const rows = db.prepare(sql).all(...args);
    sendJson(res, 200, { transactions: rows });
  });

  // Summary: totals by venture, plus grand total.
  router.get('/api/ledger/summary', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, CAN_SEE_LEDGER, res, sendError)) return;
    const byVenture = db.prepare(`
      SELECT venture,
        COALESCE(SUM(CASE WHEN entry_type = 'revenue' THEN amount ELSE 0 END), 0) as revenue,
        COALESCE(SUM(CASE WHEN entry_type = 'expense' THEN amount ELSE 0 END), 0) as expense
      FROM ledger_transactions GROUP BY venture
    `).all();
    const byCategory = db.prepare(`
      SELECT venture, category, entry_type,
        COALESCE(SUM(amount), 0) as total
      FROM ledger_transactions GROUP BY venture, category, entry_type
      ORDER BY venture, entry_type, total DESC
    `).all();
    const totals = byVenture.reduce((acc, v) => ({
      revenue: acc.revenue + v.revenue,
      expense: acc.expense + v.expense,
    }), { revenue: 0, expense: 0 });
    sendJson(res, 200, {
      by_venture: byVenture,
      by_category: byCategory,
      totals: { ...totals, net: totals.revenue - totals.expense },
    });
  });

  // Manual entries: salaries, overhead, anything not tied to a venture record.
  router.post('/api/ledger/manual', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, CAN_SEE_LEDGER, res, sendError)) return;
    const { venture, entry_type, category, amount, entry_date, notes } = body || {};
    const validVentures = ['fleet', 'sugarcane', 'passion_fruit', 'overhead'];
    if (!validVentures.includes(venture)) return sendError(res, 400, `venture must be one of ${validVentures.join(', ')}`);
    if (!['revenue', 'expense'].includes(entry_type)) return sendError(res, 400, "entry_type must be 'revenue' or 'expense'");
    if (!category || !amount) return sendError(res, 400, 'category and amount are required');
    postLedgerEntry({ venture, entry_type, category, amount, entry_date, notes, created_by: user.id });
    sendJson(res, 201, { ok: true });
  });
}
