import { db } from '../db.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth, requireRole, ROLES } from '../context.js';

export function registerLocationRoutes(router) {
  // Any authenticated user reports their own location periodically.
  router.post('/api/locations', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const { lat, lng } = body || {};
    if (typeof lat !== 'number' || typeof lng !== 'number') return sendError(res, 400, 'lat and lng (numbers) are required');
    db.prepare('INSERT INTO locations (user_id, lat, lng) VALUES (?,?,?)').run(user.id, lat, lng);
    sendJson(res, 201, { ok: true });
  });

  // Admin-only Traffic page: latest known position per user.
  router.get('/api/locations/latest', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.ADMIN], res, sendError)) return;
    const rows = db.prepare(`
      SELECT u.id as user_id, u.name, u.role, l.lat, l.lng, l.recorded_at
      FROM users u
      LEFT JOIN locations l ON l.id = (
        SELECT id FROM locations WHERE user_id = u.id ORDER BY recorded_at DESC LIMIT 1
      )
      WHERE u.active = 1 AND u.role != 'admin'
      ORDER BY u.name
    `).all();
    sendJson(res, 200, { users: rows });
  });

  // Admin-only: movement history for one user (for a trail on the map).
  router.get('/api/locations/history/:userId', async (req, res, params, body, query) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!requireRole(user, [ROLES.ADMIN], res, sendError)) return;
    const limit = Math.min(Number(query.limit) || 200, 1000);
    const rows = db.prepare(`SELECT lat, lng, recorded_at FROM locations WHERE user_id = ? ORDER BY recorded_at DESC LIMIT ?`)
      .all(params.userId, limit);
    sendJson(res, 200, { history: rows.reverse() });
  });
}
