import { db, postLedgerEntry } from '../db.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth, ROLES } from '../context.js';

const CAN_READ = [ROLES.ADMIN, ROLES.DISPATCHER, ROLES.PASSION_FRUIT_MANAGER];
function canWrite(user) {
  return user.role === ROLES.PASSION_FRUIT_MANAGER || user.role === ROLES.ADMIN;
}

function availableInventoryKg() {
  const harvested = db.prepare('SELECT COALESCE(SUM(kg),0) as total FROM passion_fruit_harvests').get().total;
  const sold = db.prepare('SELECT COALESCE(SUM(kg),0) as total FROM passion_fruit_sales').get().total;
  return harvested - sold;
}

export function registerPassionFruitRoutes(router) {
  router.get('/api/passionfruit/blocks', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!CAN_READ.includes(user.role)) return sendError(res, 403, 'Not permitted');
    const blocks = db.prepare('SELECT * FROM passion_fruit_blocks ORDER BY code').all();
    sendJson(res, 200, { blocks });
  });

  router.get('/api/passionfruit/summary', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!CAN_READ.includes(user.role)) return sendError(res, 403, 'Not permitted');
    sendJson(res, 200, { available_kg: availableInventoryKg() });
  });

  // ---- Harvests ----
  router.get('/api/passionfruit/harvests', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!CAN_READ.includes(user.role)) return sendError(res, 403, 'Not permitted');
    const rows = db.prepare(`SELECT h.*, b.code as block_code FROM passion_fruit_harvests h
      JOIN passion_fruit_blocks b ON b.id = h.block_id ORDER BY h.harvest_date DESC`).all();
    sendJson(res, 200, { harvests: rows });
  });

  router.post('/api/passionfruit/harvests', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!canWrite(user)) return sendError(res, 403, 'Not permitted');
    const { block_id, kg, harvest_date, notes } = body || {};
    if (!block_id || !kg) return sendError(res, 400, 'block_id and kg are required');
    const info = db.prepare(`INSERT INTO passion_fruit_harvests (block_id, kg, harvest_date, notes, created_by)
      VALUES (?,?,?,?,?)`).run(block_id, kg, harvest_date || new Date().toISOString(), notes || null, user.id);
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  // ---- Sales (constrained by available inventory) ----
  router.get('/api/passionfruit/sales', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!CAN_READ.includes(user.role)) return sendError(res, 403, 'Not permitted');
    const rows = db.prepare('SELECT * FROM passion_fruit_sales ORDER BY sale_date DESC').all();
    sendJson(res, 200, { sales: rows });
  });

  router.post('/api/passionfruit/sales', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!canWrite(user)) return sendError(res, 403, 'Not permitted');
    const { kg, rate_per_kg, buyer, sale_date } = body || {};
    if (!kg || !rate_per_kg) return sendError(res, 400, 'kg and rate_per_kg are required');
    const available = availableInventoryKg();
    if (kg > available) {
      return sendError(res, 400, `Only ${available.toFixed(1)} kg available in inventory`);
    }
    const info = db.prepare(`INSERT INTO passion_fruit_sales (kg, rate_per_kg, buyer, sale_date, created_by)
      VALUES (?,?,?,?,?)`).run(kg, rate_per_kg, buyer || null, sale_date || new Date().toISOString(), user.id);
    postLedgerEntry({
      venture: 'passion_fruit', entry_type: 'revenue', category: 'fruit_sale', amount: kg * rate_per_kg,
      entry_date: sale_date || new Date().toISOString(), source_table: 'passion_fruit_sales',
      source_id: info.lastInsertRowid, created_by: user.id, notes: buyer ? `Sold to ${buyer}` : null,
    });
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  // ---- Farm activities (planting, weeding, pruning, spraying, fertilizer/pesticide purchases) ----
  router.get('/api/passionfruit/activities', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!CAN_READ.includes(user.role)) return sendError(res, 403, 'Not permitted');
    const rows = db.prepare(`SELECT a.*, b.code as block_code FROM passion_fruit_activities a
      LEFT JOIN passion_fruit_blocks b ON b.id = a.block_id ORDER BY a.activity_date DESC`).all();
    sendJson(res, 200, { activities: rows });
  });

  router.post('/api/passionfruit/activities', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!canWrite(user)) return sendError(res, 403, 'Not permitted');
    const { block_id, activity_type, volume, unit, cost, activity_date, notes } = body || {};
    const validTypes = ['planting', 'weeding', 'pruning', 'spraying', 'fertilizer_purchase', 'pesticide_purchase', 'other'];
    if (!validTypes.includes(activity_type)) return sendError(res, 400, `activity_type must be one of ${validTypes.join(', ')}`);
    const info = db.prepare(`INSERT INTO passion_fruit_activities
      (block_id, activity_type, volume, unit, cost, activity_date, notes, created_by)
      VALUES (?,?,?,?,?,?,?,?)`).run(
      block_id || null, activity_type, volume || null, unit || null, cost || null,
      activity_date || new Date().toISOString(), notes || null, user.id
    );
    if (cost) {
      postLedgerEntry({
        venture: 'passion_fruit', entry_type: 'expense', category: activity_type, amount: cost,
        entry_date: activity_date || new Date().toISOString(), source_table: 'passion_fruit_activities',
        source_id: info.lastInsertRowid, created_by: user.id, notes: notes || null,
      });
    }
    sendJson(res, 201, { id: info.lastInsertRowid });
  });
}
