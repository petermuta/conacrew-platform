import { db } from '../db.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth, ROLES } from '../context.js';
import { saveBase64File, readFileBuffer } from '../files.js';
import fs from 'node:fs';

const FULL_ACCESS = [ROLES.ADMIN, ROLES.DISPATCHER];

function ventureAllowed(user, venture, operation_id) {
  if (FULL_ACCESS.includes(user.role)) return true;
  if (user.role === ROLES.SUGARCANE_MANAGER) return venture === 'sugarcane' && operation_id === user.operation_id;
  if (user.role === ROLES.PASSION_FRUIT_MANAGER) return venture === 'passion_fruit';
  if (user.role === ROLES.DRIVER) return venture === 'fleet';
  return false;
}

export function registerDocumentRoutes(router) {
  router.get('/api/documents', async (req, res, params, body, query) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    let sql = `SELECT d.id, d.venture, d.operation_id, d.ref_table, d.ref_id, d.file_name, d.mime_type, d.uploaded_at,
      u.name as uploaded_by_name FROM documents d LEFT JOIN users u ON u.id = d.uploaded_by WHERE 1=1`;
    const args = [];
    if (FULL_ACCESS.includes(user.role)) {
      if (query.venture) { sql += ' AND d.venture = ?'; args.push(query.venture); }
    } else if (user.role === ROLES.SUGARCANE_MANAGER) {
      sql += ' AND d.venture = ? AND d.operation_id = ?'; args.push('sugarcane', user.operation_id);
    } else if (user.role === ROLES.PASSION_FRUIT_MANAGER) {
      sql += " AND d.venture = 'passion_fruit'";
    } else if (user.role === ROLES.DRIVER) {
      sql += " AND d.venture = 'fleet' AND d.uploaded_by = ?"; args.push(user.id);
    } else {
      return sendError(res, 403, 'Not permitted');
    }
    if (query.ref_table) {
      sql += ' AND d.ref_table = ?'; args.push(query.ref_table);
      if (query.ref_id) { sql += ' AND d.ref_id = ?'; args.push(query.ref_id); }
    }
    sql += ' ORDER BY d.uploaded_at DESC';
    const rows = db.prepare(sql).all(...args);
    sendJson(res, 200, { documents: rows });
  });

  router.post('/api/documents', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const { venture, operation_id, ref_table, ref_id, file_name, mime_type, file_base64 } = body || {};
    if (!venture || !file_name || !file_base64) return sendError(res, 400, 'venture, file_name and file_base64 are required');
    const opId = user.role === ROLES.SUGARCANE_MANAGER ? user.operation_id : (operation_id || null);
    if (!ventureAllowed(user, venture, opId)) return sendError(res, 403, 'Not permitted for this venture');
    const filePath = saveBase64File('documents', file_base64, mime_type || 'application/octet-stream');
    const info = db.prepare(`INSERT INTO documents (venture, operation_id, ref_table, ref_id, file_name, file_path, mime_type, uploaded_by)
      VALUES (?,?,?,?,?,?,?,?)`).run(venture, opId, ref_table || null, ref_id || null, file_name, filePath, mime_type || null, user.id);
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  router.get('/api/documents/:id/file', async (req, res, params) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(params.id);
    if (!doc) return sendError(res, 404, 'Not found');
    if (!ventureAllowed(user, doc.venture, doc.operation_id) && doc.uploaded_by !== user.id) {
      return sendError(res, 403, 'Not permitted');
    }
    if (!fs.existsSync(doc.file_path)) return sendError(res, 404, 'File missing on disk');
    res.writeHead(200, {
      'Content-Type': doc.mime_type || 'application/octet-stream',
      'Content-Disposition': `inline; filename="${doc.file_name}"`,
      'Access-Control-Allow-Origin': '*',
    });
    res.end(readFileBuffer(doc.file_path));
  });
}
