import { db, postLedgerEntry } from '../db.js';
import { sendJson, sendError } from '../util.js';
import { requireAuth, ROLES } from '../context.js';

const CAN_SEE_ALL = [ROLES.ADMIN, ROLES.DISPATCHER];

// Returns the operation_id scope for a user, or 'all' for admin/dispatcher, or null if not permitted at all.
function scopeFor(user) {
  if (CAN_SEE_ALL.includes(user.role)) return 'all';
  if (user.role === ROLES.SUGARCANE_MANAGER) return user.operation_id;
  return null;
}

function canWrite(user) {
  return user.role === ROLES.SUGARCANE_MANAGER || user.role === ROLES.ADMIN;
}

export function registerSugarcaneRoutes(router) {
  router.get('/api/sugarcane/deals', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const scope = scopeFor(user);
    if (scope === null) return sendError(res, 403, 'Not permitted');
    const deals = scope === 'all'
      ? db.prepare(`SELECT d.*, o.name as operation_name FROM sugarcane_deals d
          JOIN sugarcane_operations o ON o.id = d.operation_id ORDER BY d.deal_date DESC`).all()
      : db.prepare(`SELECT d.*, o.name as operation_name FROM sugarcane_deals d
          JOIN sugarcane_operations o ON o.id = d.operation_id WHERE d.operation_id = ? ORDER BY d.deal_date DESC`).all(scope);
    sendJson(res, 200, { deals });
  });

  router.post('/api/sugarcane/deals', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!canWrite(user)) return sendError(res, 403, 'Not permitted');
    const { deal_type, farmer_name, location, acreage_size, estimated_trips, rate, deal_date, notes, operation_id } = body || {};
    if (!['acreage', 'trips'].includes(deal_type)) return sendError(res, 400, "deal_type must be 'acreage' or 'trips'");
    if (!farmer_name || !rate) return sendError(res, 400, 'farmer_name and rate are required');
    let finalOpId = user.role === ROLES.SUGARCANE_MANAGER ? user.operation_id : operation_id;
    if (!finalOpId) return sendError(res, 400, 'operation_id is required');
    if (deal_type === 'acreage' && !acreage_size) return sendError(res, 400, 'acreage_size is required for an acreage deal');
    const info = db.prepare(`INSERT INTO sugarcane_deals
      (operation_id, deal_type, farmer_name, location, acreage_size, estimated_trips, rate, deal_date, notes, created_by)
      VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
      finalOpId, deal_type, farmer_name, location || null, acreage_size || null, estimated_trips || null,
      rate, deal_date || new Date().toISOString(), notes || null, user.id
    );
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  router.patch('/api/sugarcane/deals/:id', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const deal = db.prepare('SELECT * FROM sugarcane_deals WHERE id = ?').get(params.id);
    if (!deal) return sendError(res, 404, 'Not found');
    const scope = scopeFor(user);
    if (scope !== 'all' && scope !== deal.operation_id) return sendError(res, 403, 'Not permitted');
    if (!canWrite(user)) return sendError(res, 403, 'Not permitted');
    const fields = [];
    const values = [];
    if (body.status) { fields.push('status = ?'); values.push(body.status); }
    if (body.notes !== undefined) { fields.push('notes = ?'); values.push(body.notes); }
    if (!fields.length) return sendError(res, 400, 'Nothing to update');
    values.push(params.id);
    db.prepare(`UPDATE sugarcane_deals SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    sendJson(res, 200, { ok: true });
  });

  // ---- Deal costs ----
  router.get('/api/sugarcane/deals/:id/costs', async (req, res, params) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const deal = db.prepare('SELECT * FROM sugarcane_deals WHERE id = ?').get(params.id);
    if (!deal) return sendError(res, 404, 'Not found');
    const scope = scopeFor(user);
    if (scope !== 'all' && scope !== deal.operation_id) return sendError(res, 403, 'Not permitted');
    const costs = db.prepare('SELECT * FROM sugarcane_deal_costs WHERE deal_id = ? ORDER BY cost_date DESC').all(params.id);
    sendJson(res, 200, { costs });
  });

  router.post('/api/sugarcane/deals/:id/costs', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const deal = db.prepare('SELECT * FROM sugarcane_deals WHERE id = ?').get(params.id);
    if (!deal) return sendError(res, 404, 'Not found');
    const scope = scopeFor(user);
    if (scope !== 'all' && scope !== deal.operation_id) return sendError(res, 403, 'Not permitted');
    if (!canWrite(user)) return sendError(res, 403, 'Not permitted');
    const { category, amount, note, cost_date } = body || {};
    const validCats = ['truck', 'fuel', 'driver', 'loaders', 'cutters', 'farmer_payment', 'other'];
    if (!validCats.includes(category)) return sendError(res, 400, `category must be one of ${validCats.join(', ')}`);
    if (!amount) return sendError(res, 400, 'amount is required');
    const info = db.prepare(`INSERT INTO sugarcane_deal_costs (deal_id, category, amount, note, cost_date, created_by)
      VALUES (?,?,?,?,?,?)`).run(params.id, category, amount, note || null, cost_date || new Date().toISOString(), user.id);
    postLedgerEntry({
      venture: 'sugarcane', operation_id: deal.operation_id, entry_type: 'expense', category, amount,
      entry_date: cost_date || new Date().toISOString(), source_table: 'sugarcane_deal_costs',
      source_id: info.lastInsertRowid, created_by: user.id, notes: note || `Deal #${params.id} (${deal.farmer_name})`,
    });
    sendJson(res, 201, { id: info.lastInsertRowid });
  });

  // ---- Sales ----
  router.get('/api/sugarcane/sales', async (req, res) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    const scope = scopeFor(user);
    if (scope === null) return sendError(res, 403, 'Not permitted');
    const sales = scope === 'all'
      ? db.prepare(`SELECT s.*, o.name as operation_name FROM sugarcane_sales s
          JOIN sugarcane_operations o ON o.id = s.operation_id ORDER BY s.sale_date DESC`).all()
      : db.prepare(`SELECT s.*, o.name as operation_name FROM sugarcane_sales s
          JOIN sugarcane_operations o ON o.id = s.operation_id WHERE s.operation_id = ? ORDER BY s.sale_date DESC`).all(scope);
    sendJson(res, 200, { sales });
  });

  router.post('/api/sugarcane/sales', async (req, res, params, body) => {
    const user = requireAuth(req, res, sendError);
    if (!user) return;
    if (!canWrite(user)) return sendError(res, 403, 'Not permitted');
    const { deal_id, tonnage, rate_per_ton, buyer, sale_date, operation_id } = body || {};
    if (!tonnage || !rate_per_ton) return sendError(res, 400, 'tonnage and rate_per_ton are required');
    let finalOpId = user.role === ROLES.SUGARCANE_MANAGER ? user.operation_id : operation_id;
    if (!finalOpId) return sendError(res, 400, 'operation_id is required');
    const info = db.prepare(`INSERT INTO sugarcane_sales (operation_id, deal_id, tonnage, rate_per_ton, buyer, sale_date, created_by)
      VALUES (?,?,?,?,?,?,?)`).run(finalOpId, deal_id || null, tonnage, rate_per_ton, buyer || null,
      sale_date || new Date().toISOString(), user.id);
    postLedgerEntry({
      venture: 'sugarcane', operation_id: finalOpId, entry_type: 'revenue', category: 'cane_sale',
      amount: tonnage * rate_per_ton, entry_date: sale_date || new Date().toISOString(),
      source_table: 'sugarcane_sales', source_id: info.lastInsertRowid, created_by: user.id,
      notes: buyer ? `Sold to ${buyer}` : null,
    });
    sendJson(res, 201, { id: info.lastInsertRowid });
  });
}
