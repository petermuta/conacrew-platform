import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Router, readJsonBody, sendError } from './util.js';
import { registerAuthRoutes } from './routes/auth.js';
import { registerUserRoutes } from './routes/users.js';
import { registerFleetRoutes } from './routes/fleet.js';
import { registerSugarcaneRoutes } from './routes/sugarcane.js';
import { registerPassionFruitRoutes } from './routes/passionfruit.js';
import { registerLedgerRoutes } from './routes/ledger.js';
import { registerDocumentRoutes } from './routes/documents.js';
import { registerLocationRoutes } from './routes/locations.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const clientDir = path.join(__dirname, '..', '..', 'client');
const PORT = process.env.PORT || 8787;

const router = new Router();
registerAuthRoutes(router);
registerUserRoutes(router);
registerFleetRoutes(router);
registerSugarcaneRoutes(router);
registerPassionFruitRoutes(router);
registerLedgerRoutes(router);
registerDocumentRoutes(router);
registerLocationRoutes(router);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};

function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  let filePath = path.join(clientDir, rel);
  if (!filePath.startsWith(clientDir)) {
    res.writeHead(403); res.end('Forbidden'); return;
  }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(clientDir, 'index.html'); // SPA fallback for client-side hash routing
  }
  const ext = path.extname(filePath);
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname;
  const query = Object.fromEntries(url.searchParams.entries());

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS',
    });
    return res.end();
  }

  if (!pathname.startsWith('/api/')) {
    return serveStatic(req, res, pathname);
  }

  const match = router.match(req.method, pathname);
  if (!match) {
    return sendError(res, 404, 'No such API route');
  }
  try {
    const body = (req.method === 'POST' || req.method === 'PATCH') ? await readJsonBody(req) : {};
    await match.handler(req, res, match.params, body, query);
  } catch (e) {
    console.error(e);
    sendError(res, 500, e.message || 'Internal server error');
  }
});

server.listen(PORT, () => {
  console.log(`Conacrew API + client listening on http://localhost:${PORT}`);
});
