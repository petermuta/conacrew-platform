import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// UPLOADS_DIR mirrors DATA_DIR (see db.js) so documents/voice notes also
// live on a persistent Disk when hosted, instead of the deployed code folder.
const uploadsRoot = process.env.UPLOADS_DIR || path.join(__dirname, '..', 'uploads');

const EXT_BY_MIME = {
  'audio/webm': 'webm',
  'audio/mp4': 'm4a',
  'audio/mpeg': 'mp3',
  'audio/ogg': 'ogg',
  'application/pdf': 'pdf',
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};

// Accepts either a raw base64 string or a data: URL; strips the data: prefix if present.
export function saveBase64File(subdir, base64Input, mimeType) {
  const dir = path.join(uploadsRoot, subdir);
  fs.mkdirSync(dir, { recursive: true });
  let data = base64Input;
  let mime = mimeType;
  const match = /^data:([^;]+);base64,(.*)$/s.exec(base64Input);
  if (match) {
    mime = match[1];
    data = match[2];
  }
  const ext = EXT_BY_MIME[mime] || 'bin';
  const fileName = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}.${ext}`;
  const fullPath = path.join(dir, fileName);
  fs.writeFileSync(fullPath, Buffer.from(data, 'base64'));
  return fullPath;
}

export function readFileBuffer(fullPath) {
  return fs.readFileSync(fullPath);
}
