import { db } from './db.js';
import { hashPassword } from './auth.js';

function upsertUser({ name, email, password, role, operation_id = null }) {
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return existing.id;
  const info = db.prepare(
    'INSERT INTO users (name, email, password_hash, role, operation_id) VALUES (?,?,?,?,?)'
  ).run(name, email, hashPassword(password), role, operation_id);
  return info.lastInsertRowid;
}

// Sugarcane operations (the two isolated manager-run operations)
let op1 = db.prepare('SELECT id FROM sugarcane_operations WHERE name = ?').get('Operation A');
if (!op1) {
  const info = db.prepare('INSERT INTO sugarcane_operations (name) VALUES (?)').run('Operation A');
  op1 = { id: info.lastInsertRowid };
}
let op2 = db.prepare('SELECT id FROM sugarcane_operations WHERE name = ?').get('Operation B');
if (!op2) {
  const info = db.prepare('INSERT INTO sugarcane_operations (name) VALUES (?)').run('Operation B');
  op2 = { id: info.lastInsertRowid };
}

// Passion fruit blocks B1-B4
for (const code of ['B1', 'B2', 'B3', 'B4']) {
  const existing = db.prepare('SELECT id FROM passion_fruit_blocks WHERE code = ?').get(code);
  if (!existing) db.prepare('INSERT INTO passion_fruit_blocks (code) VALUES (?)').run(code);
}

const adminId = upsertUser({
  name: 'Peter',
  email: 'peter@conacrew.app',
  password: 'ChangeMe123!',
  role: 'admin',
});

const dispatcherId = upsertUser({
  name: 'Dispatcher',
  email: 'dispatcher@conacrew.app',
  password: 'ChangeMe123!',
  role: 'dispatcher',
});

const sc1Id = upsertUser({
  name: 'Sugarcane Manager - Operation A',
  email: 'sugarcane.a@conacrew.app',
  password: 'ChangeMe123!',
  role: 'sugarcane_manager',
  operation_id: op1.id,
});

const sc2Id = upsertUser({
  name: 'Sugarcane Manager - Operation B',
  email: 'sugarcane.b@conacrew.app',
  password: 'ChangeMe123!',
  role: 'sugarcane_manager',
  operation_id: op2.id,
});

const pfId = upsertUser({
  name: 'Passion Fruit Manager',
  email: 'passionfruit@conacrew.app',
  password: 'ChangeMe123!',
  role: 'passion_fruit_manager',
});

// A couple of demo drivers + trucks so Fleet flows can be exercised
const driver1Id = upsertUser({
  name: 'Meddy Semukuttu',
  email: 'meddy@conacrew.app',
  password: 'ChangeMe123!',
  role: 'driver',
});
const driver2Id = upsertUser({
  name: 'Paul Balikaita',
  email: 'paul@conacrew.app',
  password: 'ChangeMe123!',
  role: 'driver',
});

function upsertTruck(plate_no, driver_id) {
  const existing = db.prepare('SELECT id FROM fleet_trucks WHERE plate_no = ?').get(plate_no);
  if (existing) return existing.id;
  const info = db.prepare('INSERT INTO fleet_trucks (plate_no, driver_id) VALUES (?,?)').run(plate_no, driver_id);
  return info.lastInsertRowid;
}
upsertTruck('UA 687BH', driver1Id);
upsertTruck('UA 764AN', driver2Id);

console.log('Seed complete.');
console.log('Login accounts (change these passwords after first login):');
console.log('  Admin:              peter@conacrew.app / ChangeMe123!');
console.log('  Dispatcher:         dispatcher@conacrew.app / ChangeMe123!');
console.log('  Sugarcane Mgr A:    sugarcane.a@conacrew.app / ChangeMe123!');
console.log('  Sugarcane Mgr B:    sugarcane.b@conacrew.app / ChangeMe123!');
console.log('  Passion Fruit Mgr:  passionfruit@conacrew.app / ChangeMe123!');
console.log('  Driver (demo):      meddy@conacrew.app / ChangeMe123!');
console.log('  Driver (demo):      paul@conacrew.app / ChangeMe123!');
