// Minimal, safe DOM-building helper. No innerHTML for user data -> no XSS surface.
export function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'html') node.innerHTML = v; // only ever pass trusted static markup here
    else if (v === true) node.setAttribute(k, '');
    else node.setAttribute(k, v);
  }
  const list = Array.isArray(children) ? children : [children];
  for (const child of list) {
    if (child === null || child === undefined || child === false) continue;
    node.appendChild(typeof child === 'string' || typeof child === 'number' ? document.createTextNode(String(child)) : child);
  }
  return node;
}

export function clear(node) {
  while (node.firstChild) node.removeChild(node.firstChild);
}

export function mount(root, node) {
  clear(root);
  root.appendChild(node);
}

export function fmtMoney(n) {
  const num = Number(n) || 0;
  return 'UGX ' + num.toLocaleString('en-UG', { maximumFractionDigits: 0 });
}

export function fmtDate(s) {
  if (!s) return '—';
  const d = new Date(s);
  if (isNaN(d)) return s;
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function fmtDateTime(s) {
  if (!s) return '—';
  const d = new Date(s);
  if (isNaN(d)) return s;
  return d.toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export function badge(text) {
  return el('span', { class: `badge badge-${text}` }, text.replace(/_/g, ' '));
}

// For labels that need to differ from the status keyword driving the color (e.g. "Active" vs the "resolved" green).
export function badgeAs(statusKey, label) {
  return el('span', { class: `badge badge-${statusKey}` }, label);
}

let toastTimer = null;
export function toast(message, kind = '') {
  document.querySelectorAll('.toast').forEach((t) => t.remove());
  const node = el('div', { class: `toast ${kind}` }, message);
  document.body.appendChild(node);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.remove(), 3500);
}

export function openModal(contentNode) {
  const backdrop = el('div', { class: 'modal-backdrop', onclick: (e) => { if (e.target === backdrop) close(); } }, [
    el('div', { class: 'modal' }, contentNode),
  ]);
  function close() { backdrop.remove(); }
  document.body.appendChild(backdrop);
  return close;
}
