import { el, mount, clear } from './dom.js';
import { getToken, getUser, clearSession, api, setSession } from './api.js';
import { startLocationTracking } from './location.js';

import { renderLogin } from './pages/login.js';
import { renderDashboard } from './pages/dashboard.js';
import { renderFleet } from './pages/fleet.js';
import { renderSugarcane } from './pages/sugarcane.js';
import { renderPassionFruit } from './pages/passionfruit.js';
import { renderAccounting } from './pages/accounting.js';
import { renderTraffic } from './pages/traffic.js';
import { renderUsers } from './pages/users.js';
import { renderDriverHome } from './pages/driverhome.js';
import { renderDocuments } from './pages/documents.js';

const root = document.getElementById('app');

const NAV = {
  admin: [
    ['#/dashboard', 'Dashboard'],
    ['#/fleet', 'Fleet'],
    ['#/sugarcane', 'Sugarcane'],
    ['#/passionfruit', 'Passion Fruit'],
    ['#/accounting', 'Accounting'],
    ['#/documents', 'Documents'],
    ['#/traffic', 'Traffic'],
    ['#/users', 'Users'],
  ],
  dispatcher: [
    ['#/dashboard', 'Dashboard'],
    ['#/fleet', 'Fleet'],
    ['#/sugarcane', 'Sugarcane'],
    ['#/passionfruit', 'Passion Fruit'],
    ['#/accounting', 'Accounting'],
    ['#/documents', 'Documents'],
  ],
  sugarcane_manager: [
    ['#/dashboard', 'Dashboard'],
    ['#/sugarcane', 'Sugarcane'],
  ],
  passion_fruit_manager: [
    ['#/dashboard', 'Dashboard'],
    ['#/passionfruit', 'Passion Fruit'],
  ],
  driver: [
    ['#/driver', 'My Work'],
  ],
};

const PAGES = {
  '/dashboard': renderDashboard,
  '/fleet': renderFleet,
  '/sugarcane': renderSugarcane,
  '/passionfruit': renderPassionFruit,
  '/accounting': renderAccounting,
  '/documents': renderDocuments,
  '/traffic': renderTraffic,
  '/users': renderUsers,
  '/driver': renderDriverHome,
};

function defaultRouteFor(user) {
  return user.role === 'driver' ? '#/driver' : '#/dashboard';
}

function layout(user, path) {
  const nav = NAV[user.role] || [];
  const sidebar = el('div', { class: 'sidebar', id: 'sidebar' }, [
    el('div', { class: 'brand' }, [
      el('img', { src: '/assets/logo.png', alt: 'Conacrew' }),
      el('div', {}, [
        el('div', { class: 'name' }, 'CONACREW'),
        el('div', { class: 'sub' }, 'BUSINESS PLATFORM'),
      ]),
    ]),
    el('div', { class: 'nav-group' }, nav.map(([href, label]) =>
      el('a', {
        class: `nav-link${path === href.slice(1) ? ' active' : ''}`,
        href,
        onclick: () => document.getElementById('sidebar')?.classList.remove('open'),
      }, label)
    )),
    el('div', { class: 'sidebar-footer' }, [
      el('div', { class: 'who' }, user.name),
      el('div', { class: 'role' }, user.role.replace(/_/g, ' ')),
      el('button', { class: 'btn btn-ghost btn-sm', style: { width: '100%' }, onclick: logout }, 'Log out'),
    ]),
  ]);

  const scrim = el('div', { class: 'sidebar-scrim', onclick: () => { sidebar.classList.remove('open'); scrim.classList.remove('open'); } });

  const topbar = el('div', { class: 'topbar' }, [
    el('button', { class: 'hamburger', onclick: () => { sidebar.classList.toggle('open'); scrim.classList.toggle('open'); } }, '☰'),
    el('div', { class: 'brand' }, [
      el('img', { src: '/assets/logo.png', alt: 'Conacrew' }),
      el('div', { class: 'name' }, 'CONACREW'),
    ]),
    el('div', {}),
  ]);

  const content = el('div', { class: 'content', id: 'content' });
  const main = el('div', { class: 'main' }, [topbar, content]);
  const shell = el('div', { class: 'shell' }, [sidebar, scrim, main]);
  mount(root, shell);
  return content;
}

function logout() {
  clearSession();
  window.location.hash = '#/login';
}

async function route() {
  const hash = window.location.hash || '#/login';
  const path = hash.replace(/^#/, '') || '/login';
  const user = getUser();
  const token = getToken();

  if (path === '/login') {
    if (user && token) { window.location.hash = defaultRouteFor(user); return; }
    mount(root, renderLogin({ onLoggedIn: (u) => { window.location.hash = defaultRouteFor(u); } }));
    return;
  }

  if (!user || !token) { window.location.hash = '#/login'; return; }

  const allowedPaths = (NAV[user.role] || []).map(([h]) => h.slice(1));
  if (!allowedPaths.includes(path)) {
    window.location.hash = defaultRouteFor(user);
    return;
  }

  const content = layout(user, path);
  const pageFn = PAGES[path];
  if (pageFn) {
    try {
      await pageFn(content, user);
    } catch (e) {
      clear(content);
      content.appendChild(el('div', { class: 'card' }, `Something went wrong loading this page: ${e.message}`));
    }
  }
}

window.addEventListener('hashchange', route);
window.addEventListener('DOMContentLoaded', () => {
  route();
  const user = getUser();
  if (user && getToken()) startLocationTracking();
});
