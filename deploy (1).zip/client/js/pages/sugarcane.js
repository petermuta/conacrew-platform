import { el, clear, fmtMoney, fmtDate, badge, toast, openModal } from '../dom.js';
import { api } from '../api.js';

const COST_CATS = ['truck', 'fuel', 'driver', 'loaders', 'cutters', 'farmer_payment', 'other'];

function dealForm(operations, user, onSubmit) {
  const dealType = el('select', {}, [el('option', { value: 'acreage' }, 'Acreage'), el('option', { value: 'trips' }, 'Trips')]);
  const opSel = user.role === 'admin'
    ? el('select', { required: true }, [el('option', { value: '' }, 'Select operation'), ...operations.map((o) => el('option', { value: o.id }, o.name))])
    : null;
  const farmer = el('input', { required: true, placeholder: 'Farmer name' });
  const location = el('input', { placeholder: 'Location' });
  const acreage = el('input', { type: 'number', step: '0.1', placeholder: 'Acres' });
  const trips = el('input', { type: 'number', step: '1', placeholder: 'Estimated trips' });
  const rate = el('input', { type: 'number', step: '0.01', required: true, placeholder: 'UGX' });
  const dateInput = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
  const errorBox = el('div', { class: 'error-text' });

  const acreageWrap = el('div', { class: 'field' }, [el('label', {}, 'Acreage size'), acreage]);
  const tripsWrap = el('div', { class: 'field' }, [el('label', {}, 'Estimated trips'), trips]);

  function syncVisibility() {
    acreageWrap.style.display = dealType.value === 'acreage' ? '' : 'none';
  }
  dealType.addEventListener('change', syncVisibility);
  syncVisibility();

  const form = el('form', {
    onsubmit: async (e) => {
      e.preventDefault();
      errorBox.textContent = '';
      try {
        await onSubmit({
          deal_type: dealType.value,
          operation_id: opSel ? Number(opSel.value) : undefined,
          farmer_name: farmer.value,
          location: location.value || null,
          acreage_size: dealType.value === 'acreage' ? Number(acreage.value) : null,
          estimated_trips: trips.value ? Number(trips.value) : null,
          rate: Number(rate.value),
          deal_date: dateInput.value,
        });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'New sugarcane deal'),
    el('div', { class: 'field' }, [el('label', {}, 'Deal type'), dealType]),
    opSel ? el('div', { class: 'field' }, [el('label', {}, 'Operation'), opSel]) : null,
    el('div', { class: 'field' }, [el('label', {}, 'Farmer'), farmer]),
    el('div', { class: 'field' }, [el('label', {}, 'Location'), location]),
    el('div', { class: 'form-row' }, [acreageWrap, tripsWrap]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, dealType.value === 'acreage' ? 'Rate per acre (UGX)' : 'Rate per trip (UGX)'), rate]),
      el('div', { class: 'field' }, [el('label', {}, 'Date'), dateInput]),
    ]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Create deal')]),
  ]);
  return form;
}

function costForm(dealId, onSubmit) {
  const category = el('select', {}, COST_CATS.map((c) => el('option', { value: c }, c.replace(/_/g, ' '))));
  const amount = el('input', { type: 'number', step: '0.01', required: true, placeholder: 'UGX' });
  const note = el('input', { placeholder: 'Note (optional)' });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault();
      errorBox.textContent = '';
      try { await onSubmit({ category: category.value, amount: Number(amount.value), note: note.value || null }); }
      catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Add cost'),
    el('div', { class: 'field' }, [el('label', {}, 'Category'), category]),
    el('div', { class: 'field' }, [el('label', {}, 'Amount (UGX)'), amount]),
    el('div', { class: 'field' }, [el('label', {}, 'Note'), note]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Add cost')]),
  ]);
}

function saleForm(operations, user, onSubmit) {
  const opSel = user.role === 'admin'
    ? el('select', { required: true }, [el('option', { value: '' }, 'Select operation'), ...operations.map((o) => el('option', { value: o.id }, o.name))])
    : null;
  const tonnage = el('input', { type: 'number', step: '0.01', required: true, placeholder: 'Tonnes' });
  const rate = el('input', { type: 'number', step: '0.01', required: true, placeholder: 'UGX per tonne' });
  const buyer = el('input', { placeholder: 'Buyer' });
  const dateInput = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault();
      errorBox.textContent = '';
      try {
        await onSubmit({
          operation_id: opSel ? Number(opSel.value) : undefined,
          tonnage: Number(tonnage.value), rate_per_ton: Number(rate.value),
          buyer: buyer.value || null, sale_date: dateInput.value,
        });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Record a sale'),
    opSel ? el('div', { class: 'field' }, [el('label', {}, 'Operation'), opSel]) : null,
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Tonnage'), tonnage]),
      el('div', { class: 'field' }, [el('label', {}, 'Rate per tonne (UGX)'), rate]),
    ]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Buyer'), buyer]),
      el('div', { class: 'field' }, [el('label', {}, 'Date'), dateInput]),
    ]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Record sale')]),
  ]);
}

async function renderDealsTab(container, user, operations) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const { deals } = await api.get('/api/sugarcane/deals');
  clear(container);
  const canWrite = user.role === 'admin' || user.role === 'sugarcane_manager';

  if (canWrite) {
    container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
      el('button', {
        class: 'btn btn-accent btn-sm',
        onclick: () => {
          const form = dealForm(operations, user, async (payload) => {
            await api.post('/api/sugarcane/deals', payload);
            close(); toast('Deal created', 'success'); renderDealsTab(container, user, operations);
          });
          const close = openModal(form);
        },
      }, '+ New deal')));
  }

  const rows = deals.map((d) => el('tr', {}, [
    el('td', {}, fmtDate(d.deal_date)),
    el('td', {}, d.operation_name),
    el('td', {}, d.deal_type),
    el('td', {}, d.farmer_name),
    el('td', {}, d.deal_type === 'acreage' ? `${d.acreage_size} acres` : `${d.estimated_trips || '—'} trips`),
    el('td', { class: 'mono' }, fmtMoney(d.rate)),
    el('td', {}, badge(d.status)),
    el('td', {}, canWrite ? el('button', {
      class: 'btn btn-ghost btn-sm',
      onclick: () => {
        const form = costForm(d.id, async (payload) => {
          await api.post(`/api/sugarcane/deals/${d.id}/costs`, payload);
          close(); toast('Cost added', 'success');
        });
        const close = openModal(form);
      },
    }, 'Add cost') : '—'),
  ]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Operation', 'Type', 'Farmer', 'Size/Trips', 'Rate', 'Status', ''].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 8 }, 'No deals yet.'))),
  ]))));
}

async function renderSalesTab(container, user, operations) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const { sales } = await api.get('/api/sugarcane/sales');
  clear(container);
  const canWrite = user.role === 'admin' || user.role === 'sugarcane_manager';

  if (canWrite) {
    container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
      el('button', {
        class: 'btn btn-accent btn-sm',
        onclick: () => {
          const form = saleForm(operations, user, async (payload) => {
            await api.post('/api/sugarcane/sales', payload);
            close(); toast('Sale recorded', 'success'); renderSalesTab(container, user, operations);
          });
          const close = openModal(form);
        },
      }, '+ Record sale')));
  }

  const rows = sales.map((s) => el('tr', {}, [
    el('td', {}, fmtDate(s.sale_date)),
    el('td', {}, s.operation_name),
    el('td', {}, s.buyer || '—'),
    el('td', { class: 'mono' }, `${s.tonnage} t`),
    el('td', { class: 'mono' }, fmtMoney(s.rate_per_ton)),
    el('td', { class: 'mono' }, fmtMoney(s.tonnage * s.rate_per_ton)),
  ]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Operation', 'Buyer', 'Tonnage', 'Rate/t', 'Total'].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 6 }, 'No sales yet.'))),
  ]))));
}

export async function renderSugarcane(content, user) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, 'Sugarcane Trading'), el('p', {}, 'Deals, costs and sales.')]),
  ]));
  const { operations } = await api.get('/api/sugarcane/operations');

  const tabsDef = [['deals', 'Deals & costs', renderDealsTab], ['sales', 'Sales', renderSalesTab]];
  const body = el('div', {});
  const tabsBar = el('div', { class: 'tabs' });
  function activate(key) {
    tabsBar.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.key === key));
    tabsDef.find(([k]) => k === key)[2](body, user, operations);
  }
  tabsDef.forEach(([key, label]) => tabsBar.appendChild(el('div', { class: 'tab', 'data-key': key, onclick: () => activate(key) }, label)));
  content.appendChild(tabsBar);
  content.appendChild(body);
  activate('deals');
}
