import { el } from '../dom.js';
import { api, setSession } from '../api.js';
import { startLocationTracking } from '../location.js';

export function renderLogin({ onLoggedIn }) {
  const errorBox = el('div', { class: 'error-text' }, '');
  const emailInput = el('input', { type: 'email', autocomplete: 'username', required: true });
  const passInput = el('input', { type: 'password', autocomplete: 'current-password', required: true });
  const submitBtn = el('button', { class: 'btn btn-primary', type: 'submit' }, 'Log in');

  const form = el('form', {
    onsubmit: async (e) => {
      e.preventDefault();
      errorBox.textContent = '';
      submitBtn.disabled = true;
      submitBtn.textContent = 'Logging in…';
      try {
        const data = await api.post('/api/auth/login', { email: emailInput.value.trim(), password: passInput.value });
        setSession(data.token, data.user);
        startLocationTracking();
        onLoggedIn(data.user);
      } catch (err) {
        errorBox.textContent = err.message || 'Login failed';
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Log in';
      }
    },
  }, [
    el('div', { class: 'field' }, [el('label', {}, 'Email'), emailInput]),
    el('div', { class: 'field' }, [el('label', {}, 'Password'), passInput]),
    errorBox,
    submitBtn,
  ]);

  return el('div', { class: 'login-wrap' }, [
    el('div', { class: 'login-card' }, [
      el('img', { class: 'logo', src: '/assets/logo.png', alt: 'Conacrew' }),
      el('h1', {}, 'Conacrew'),
      form,
    ]),
  ]);
}
