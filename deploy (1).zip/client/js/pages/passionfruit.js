import { el, clear, fmtMoney, fmtDate, toast, openModal } from '../dom.js';
import { api } from '../api.js';

const ACTIVITY_TYPES = ['planting', 'weeding', 'pruning', 'spraying', 'fertilizer_purchase', 'pesticide_purchase', 'other'];

function harvestForm(blocks, onSubmit) {
  const blockSel = el('select', { required: true }, blocks.map((b) => el('option', { value: b.id }, b.code)));
  const kg = el('input', { type: 'number', step: '0.1', required: true, placeholder: 'Kg' });
  const dateInput = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
  const notes = el('input', { placeholder: 'Notes (optional)' });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      try { await onSubmit({ block_id: Number(blockSel.value), kg: Number(kg.value), harvest_date: dateInput.value, notes: notes.value || null }); }
      catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Log a harvest'),
    el('div', { class: 'field' }, [el('label', {}, 'Block'), blockSel]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Kg harvested'), kg]),
      el('div', { class: 'field' }, [el('label', {}, 'Date'), dateInput]),
    ]),
    el('div', { class: 'field' }, [el('label', {}, 'Notes'), notes]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Log harvest')]),
  ]);
}

function saleForm(availableKg, onSubmit) {
  const kg = el('input', { type: 'number', step: '0.1', required: true, placeholder: 'Kg' });
  const rate = el('input', { type: 'number', step: '0.01', required: true, placeholder: 'UGX per kg' });
  const buyer = el('input', { placeholder: 'Buyer' });
  const dateInput = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      try { await onSubmit({ kg: Number(kg.value), rate_per_kg: Number(rate.value), buyer: buyer.value || null, sale_date: dateInput.value }); }
      catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Record a sale'),
    el('p', { class: 'hint-text' }, `Available inventory: ${availableKg.toLocaleString()} kg`),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Kg sold'), kg]),
      el('div', { class: 'field' }, [el('label', {}, 'Rate per kg (UGX)'), rate]),
    ]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Buyer'), buyer]),
      el('div', { class: 'field' }, [el('label', {}, 'Date'), dateInput]),
    ]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Record sale')]),
  ]);
}

function activityForm(blocks, onSubmit) {
  const type = el('select', {}, ACTIVITY_TYPES.map((t) => el('option', { value: t }, t.replace(/_/g, ' '))));
  const blockSel = el('select', {}, [el('option', { value: '' }, 'Whole farm'), ...blocks.map((b) => el('option', { value: b.id }, b.code))]);
  const volume = el('input', { type: 'number', step: '0.01', placeholder: 'Volume (optional)' });
  const unit = el('input', { placeholder: 'Unit e.g. litres, kg' });
  const cost = el('input', { type: 'number', step: '0.01', placeholder: 'Cost UGX (optional)' });
  const dateInput = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
  const notes = el('input', { placeholder: 'Notes' });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      try {
        await onSubmit({
          activity_type: type.value, block_id: blockSel.value ? Number(blockSel.value) : null,
          volume: volume.value ? Number(volume.value) : null, unit: unit.value || null,
          cost: cost.value ? Number(cost.value) : null, activity_date: dateInput.value, notes: notes.value || null,
        });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Log farm activity'),
    el('div', { class: 'field' }, [el('label', {}, 'Activity'), type]),
    el('div', { class: 'field' }, [el('label', {}, 'Block'), blockSel]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Volume'), volume]),
      el('div', { class: 'field' }, [el('label', {}, 'Unit'), unit]),
    ]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Cost (UGX)'), cost]),
      el('div', { class: 'field' }, [el('label', {}, 'Date'), dateInput]),
    ]),
    el('div', { class: 'field' }, [el('label', {}, 'Notes'), notes]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Log activity')]),
  ]);
}

async function renderHarvestsTab(container, user, blocks) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const { harvests } = await api.get('/api/passionfruit/harvests');
  clear(container);
  const canWrite = user.role === 'admin' || user.role === 'passion_fruit_manager';
  if (canWrite) {
    container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
      el('button', {
        class: 'btn btn-accent btn-sm',
        onclick: () => {
          const form = harvestForm(blocks, async (payload) => {
            await api.post('/api/passionfruit/harvests', payload);
            close(); toast('Harvest logged', 'success'); renderHarvestsTab(container, user, blocks);
          });
          const close = openModal(form);
        },
      }, '+ Log harvest')));
  }
  const rows = harvests.map((h) => el('tr', {}, [el('td', {}, fmtDate(h.harvest_date)), el('td', {}, h.block_code), el('td', { class: 'mono' }, `${h.kg} kg`), el('td', {}, h.notes || '—')]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Block', 'Kg', 'Notes'].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 4 }, 'No harvests logged yet.'))),
  ]))));
}

async function renderSalesTab(container, user) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const [{ sales }, { available_kg }] = await Promise.all([api.get('/api/passionfruit/sales'), api.get('/api/passionfruit/summary')]);
  clear(container);
  const canWrite = user.role === 'admin' || user.role === 'passion_fruit_manager';
  if (canWrite) {
    container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
      el('button', {
        class: 'btn btn-accent btn-sm',
        onclick: () => {
          const form = saleForm(available_kg, async (payload) => {
            await api.post('/api/passionfruit/sales', payload);
            close(); toast('Sale recorded', 'success'); renderSalesTab(container, user);
          });
          const close = openModal(form);
        },
      }, '+ Record sale')));
  }
  const rows = sales.map((s) => el('tr', {}, [el('td', {}, fmtDate(s.sale_date)), el('td', {}, s.buyer || '—'), el('td', { class: 'mono' }, `${s.kg} kg`), el('td', { class: 'mono' }, fmtMoney(s.rate_per_kg)), el('td', { class: 'mono' }, fmtMoney(s.kg * s.rate_per_kg))]));
  container.appendChild(el('div', { class: 'card' }, [
    el('p', { class: 'hint-text' }, `Available inventory right now: ${available_kg.toLocaleString()} kg`),
    el('div', { class: 'table-wrap' }, el('table', {}, [
      el('thead', {}, el('tr', {}, ['Date', 'Buyer', 'Kg', 'Rate/kg', 'Total'].map((h) => el('th', {}, h)))),
      el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 5 }, 'No sales yet.'))),
    ])),
  ]));
}

async function renderActivitiesTab(container, user, blocks) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const { activities } = await api.get('/api/passionfruit/activities');
  clear(container);
  const canWrite = user.role === 'admin' || user.role === 'passion_fruit_manager';
  if (canWrite) {
    container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
      el('button', {
        class: 'btn btn-accent btn-sm',
        onclick: () => {
          const form = activityForm(blocks, async (payload) => {
            await api.post('/api/passionfruit/activities', payload);
            close(); toast('Activity logged', 'success'); renderActivitiesTab(container, user, blocks);
          });
          const close = openModal(form);
        },
      }, '+ Log activity')));
  }
  const rows = activities.map((a) => el('tr', {}, [
    el('td', {}, fmtDate(a.activity_date)), el('td', {}, a.activity_type.replace(/_/g, ' ')), el('td', {}, a.block_code || 'Whole farm'),
    el('td', {}, a.volume ? `${a.volume} ${a.unit || ''}` : '—'), el('td', { class: 'mono' }, a.cost ? fmtMoney(a.cost) : '—'), el('td', {}, a.notes || '—'),
  ]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Activity', 'Block', 'Volume', 'Cost', 'Notes'].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 6 }, 'No farm activities logged yet.'))),
  ]))));
}

export async function renderPassionFruit(content, user) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, 'Passion Fruit Farming'), el('p', {}, 'Harvests by block, sales, and farm activities.')]),
  ]));
  const { blocks } = await api.get('/api/passionfruit/blocks');

  const tabsDef = [
    ['harvests', 'Harvests', renderHarvestsTab],
    ['sales', 'Sales', renderSalesTab],
    ['activities', 'Farm activities', renderActivitiesTab],
  ];
  const body = el('div', {});
  const tabsBar = el('div', { class: 'tabs' });
  function activate(key) {
    tabsBar.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.key === key));
    tabsDef.find(([k]) => k === key)[2](body, user, blocks);
  }
  tabsDef.forEach(([key, label]) => tabsBar.appendChild(el('div', { class: 'tab', 'data-key': key, onclick: () => activate(key) }, label)));
  content.appendChild(tabsBar);
  content.appendChild(body);
  activate('harvests');
}
