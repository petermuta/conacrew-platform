import { el, clear, fmtDateTime } from '../dom.js';
import { api } from '../api.js';

let leafletLoading = null;
function ensureLeaflet() {
  if (window.L) return Promise.resolve();
  if (leafletLoading) return leafletLoading;
  leafletLoading = new Promise((resolve, reject) => {
    const css = document.createElement('link');
    css.rel = 'stylesheet';
    css.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css';
    document.head.appendChild(css);
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js';
    script.onload = resolve;
    script.onerror = () => reject(new Error('Could not reach the map library (check internet connection)'));
    document.head.appendChild(script);
  });
  return leafletLoading;
}

export async function renderTraffic(content) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, 'Traffic'), el('p', {}, "Where your team's devices last checked in.")]),
  ]));

  const mapEl = el('div', { class: 'map' });
  const listCard = el('div', { class: 'card' });
  content.appendChild(mapEl);
  content.appendChild(listCard);

  let usersData;
  try {
    await ensureLeaflet();
    usersData = await api.get('/api/locations/latest');
  } catch (e) {
    clear(content);
    content.appendChild(el('div', { class: 'card' }, `Could not load the map: ${e.message}`));
    return;
  }

  const known = usersData.users.filter((u) => u.lat != null);
  const map = window.L.map(mapEl).setView(known.length ? [known[0].lat, known[0].lng] : [0.3476, 32.5825], known.length ? 7 : 6);
  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
  }).addTo(map);

  const markers = [];
  known.forEach((u) => {
    const marker = window.L.marker([u.lat, u.lng]).addTo(map).bindPopup(`<strong>${u.name}</strong><br>${u.role.replace(/_/g, ' ')}<br>${fmtDateTime(u.recorded_at)}`);
    markers.push(marker);
  });
  if (known.length > 1) {
    const group = window.L.featureGroup(markers);
    map.fitBounds(group.getBounds().pad(0.3));
  }

  const rows = usersData.users.map((u) => el('tr', {}, [
    el('td', {}, u.name),
    el('td', {}, u.role.replace(/_/g, ' ')),
    el('td', {}, u.lat != null ? `${u.lat.toFixed(4)}, ${u.lng.toFixed(4)}` : 'No location yet'),
    el('td', {}, fmtDateTime(u.recorded_at)),
  ]));
  listCard.appendChild(el('h3', {}, 'Last known position'));
  listCard.appendChild(el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Name', 'Role', 'Coordinates', 'Last seen'].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows),
  ])));
}
