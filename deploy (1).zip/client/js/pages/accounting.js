import { el, clear, fmtMoney, fmtDate, toast, openModal } from '../dom.js';
import { api } from '../api.js';

function tile(label, value, cls = '') {
  return el('div', { class: 'stat-tile' }, [el('div', { class: 'label' }, label), el('div', { class: `value ${cls}` }, value)]);
}

function manualEntryForm(onSubmit) {
  const venture = el('select', {}, [
    el('option', { value: 'overhead' }, 'Overhead'),
    el('option', { value: 'fleet' }, 'Fleet'),
    el('option', { value: 'sugarcane' }, 'Sugarcane'),
    el('option', { value: 'passion_fruit' }, 'Passion Fruit'),
  ]);
  const entryType = el('select', {}, [el('option', { value: 'expense' }, 'Expense'), el('option', { value: 'revenue' }, 'Revenue')]);
  const category = el('input', { required: true, placeholder: 'e.g. staff_salary, rent, licenses' });
  const amount = el('input', { type: 'number', step: '0.01', required: true, placeholder: 'UGX' });
  const dateInput = el('input', { type: 'date', value: new Date().toISOString().slice(0, 10) });
  const notes = el('input', { placeholder: 'Notes (optional)' });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      try {
        await onSubmit({
          venture: venture.value, entry_type: entryType.value, category: category.value,
          amount: Number(amount.value), entry_date: dateInput.value, notes: notes.value || null,
        });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Add manual entry'),
    el('p', { class: 'hint-text' }, 'For salaries, rent, licenses and other overhead not tied to a venture record.'),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Venture'), venture]),
      el('div', { class: 'field' }, [el('label', {}, 'Type'), entryType]),
    ]),
    el('div', { class: 'field' }, [el('label', {}, 'Category'), category]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Amount (UGX)'), amount]),
      el('div', { class: 'field' }, [el('label', {}, 'Date'), dateInput]),
    ]),
    el('div', { class: 'field' }, [el('label', {}, 'Notes'), notes]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Add entry')]),
  ]);
}

export async function renderAccounting(content) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, 'Accounting'), el('p', {}, 'Consolidated, real-time across all three ventures.')]),
    el('button', {
      class: 'btn btn-accent',
      onclick: () => {
        const form = manualEntryForm(async (payload) => {
          await api.post('/api/ledger/manual', payload);
          close(); toast('Entry added', 'success'); load();
        });
        const close = openModal(form);
      },
    }, '+ Manual entry'),
  ]));

  const summaryWrap = el('div', {});
  const txWrap = el('div', {});
  content.appendChild(summaryWrap);
  content.appendChild(txWrap);

  const ventureLabel = { fleet: 'Fleet', sugarcane: 'Sugarcane', passion_fruit: 'Passion Fruit', overhead: 'Overhead' };

  let currentFilter = '';

  async function load() {
    clear(summaryWrap);
    clear(txWrap);
    summaryWrap.appendChild(el('p', { class: 'muted' }, 'Loading…'));
    const summary = await api.get('/api/ledger/summary');
    clear(summaryWrap);

    summaryWrap.appendChild(el('div', { class: 'grid grid-3' }, [
      tile('Revenue', fmtMoney(summary.totals.revenue)),
      tile('Expense', fmtMoney(summary.totals.expense)),
      tile('Net', fmtMoney(summary.totals.net), summary.totals.net >= 0 ? 'positive' : 'negative'),
    ]));

    const byVenture = {};
    for (const v of summary.by_venture) byVenture[v.venture] = v;
    summaryWrap.appendChild(el('div', { class: 'card' }, [
      el('h3', {}, 'By venture'),
      el('div', { class: 'table-wrap' }, el('table', {}, [
        el('thead', {}, el('tr', {}, ['Venture', 'Revenue', 'Expense', 'Net'].map((h) => el('th', {}, h)))),
        el('tbody', {}, Object.keys(ventureLabel).map((v) => {
          const row = byVenture[v] || { revenue: 0, expense: 0 };
          const net = row.revenue - row.expense;
          return el('tr', {}, [
            el('td', {}, ventureLabel[v]),
            el('td', { class: 'mono' }, fmtMoney(row.revenue)),
            el('td', { class: 'mono' }, fmtMoney(row.expense)),
            el('td', { class: 'mono' }, fmtMoney(net)),
          ]);
        })),
      ])),
    ]));

    await loadTransactions();
  }

  async function loadTransactions() {
    clear(txWrap);
    const tabsBar = el('div', { class: 'tabs' });
    ['', 'fleet', 'sugarcane', 'passion_fruit', 'overhead'].forEach((v) => {
      tabsBar.appendChild(el('div', {
        class: `tab${currentFilter === v ? ' active' : ''}`,
        onclick: () => { currentFilter = v; loadTransactions(); },
      }, v ? ventureLabel[v] : 'All'));
    });
    txWrap.appendChild(tabsBar);
    const body = el('p', { class: 'muted' }, 'Loading…');
    txWrap.appendChild(body);
    const q = currentFilter ? `?venture=${currentFilter}` : '';
    const { transactions } = await api.get(`/api/ledger/transactions${q}`);
    body.remove();
    const rows = transactions.map((t) => el('tr', {}, [
      el('td', {}, fmtDate(t.entry_date)),
      el('td', {}, ventureLabel[t.venture] + (t.operation_name ? ` — ${t.operation_name}` : '')),
      el('td', {}, t.category.replace(/_/g, ' ')),
      el('td', {}, t.entry_type === 'revenue' ? 'Revenue' : 'Expense'),
      el('td', { class: `mono ${t.entry_type === 'revenue' ? '' : 'error-text'}` }, `${t.entry_type === 'revenue' ? '+' : '-'}${fmtMoney(t.amount)}`),
      el('td', {}, t.notes || '—'),
      el('td', {}, t.created_by_name || '—'),
    ]));
    txWrap.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
      el('thead', {}, el('tr', {}, ['Date', 'Venture', 'Category', 'Type', 'Amount', 'Notes', 'By'].map((h) => el('th', {}, h)))),
      el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 7 }, 'No transactions yet.'))),
    ]))));
  }

  await load();
}
