import { el, clear, fmtDateTime, toast, openModal } from '../dom.js';
import { api, fileUrl } from '../api.js';

const VENTURE_LABELS = {
  fleet: 'Fleet',
  sugarcane: 'Sugarcane',
  passion_fruit: 'Passion Fruit',
  overhead: 'Overhead',
};

const REF_LABELS = {
  expense_requests: 'Expense request',
  fleet_issues: 'Issue report',
};

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function uploadForm(onSubmit) {
  const venture = el('select', {}, Object.entries(VENTURE_LABELS).map(([v, label]) => el('option', { value: v }, label)));
  const fileInput = el('input', { type: 'file', accept: 'image/*,application/pdf', required: true });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault();
      errorBox.textContent = '';
      const file = fileInput.files[0];
      if (!file) { errorBox.textContent = 'Choose a file first'; return; }
      try {
        const base64 = await fileToBase64(file);
        await onSubmit({ venture: venture.value, file_name: file.name, mime_type: file.type, file_base64: base64 });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Add a document'),
    el('div', { class: 'field' }, [el('label', {}, 'Which venture is this for?'), venture]),
    el('div', { class: 'field' }, [el('label', {}, 'File (receipt, invoice, photo…)'), fileInput]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Upload')]),
  ]);
}

export async function renderDocuments(content, user) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, 'Documents'), el('p', {}, 'Receipts, invoices, and photos submitted across the business.')]),
  ]));

  content.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
    el('button', {
      class: 'btn btn-accent btn-sm',
      onclick: () => {
        const form = uploadForm(async (payload) => {
          await api.post('/api/documents', payload);
          close();
          toast('Document uploaded', 'success');
          load();
        });
        const close = openModal(form);
      },
    }, '+ Add document')));

  const body = el('div', {}, el('p', { class: 'muted' }, 'Loading…'));
  content.appendChild(body);

  async function load() {
    clear(body);
    body.appendChild(el('p', { class: 'muted' }, 'Loading…'));
    const { documents } = await api.get('/api/documents');
    clear(body);
    const rows = documents.map((d) => el('tr', {}, [
      el('td', {}, fmtDateTime(d.uploaded_at)),
      el('td', {}, VENTURE_LABELS[d.venture] || d.venture),
      el('td', {}, d.file_name),
      el('td', {}, d.ref_table ? (REF_LABELS[d.ref_table] || d.ref_table) + (d.ref_id ? ` #${d.ref_id}` : '') : '—'),
      el('td', {}, d.uploaded_by_name || '—'),
      el('td', {}, el('a', { href: fileUrl(d.id), target: '_blank', class: 'btn btn-ghost btn-sm' }, 'View')),
    ]));
    body.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
      el('thead', {}, el('tr', {}, ['Date', 'Venture', 'File', 'Linked to', 'Uploaded by', ''].map((h) => el('th', {}, h)))),
      el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 6 }, 'No documents submitted yet.'))),
    ]))));
  }

  await load();
}
