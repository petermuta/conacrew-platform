import { el, clear, fmtMoney, fmtDate, badge, toast, openModal } from '../dom.js';
import { api, fileUrl } from '../api.js';

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// ---------------- My Loads ----------------
function loadForm(trucks, onSubmit) {
  const truckSel = el('select', {}, [el('option', { value: '' }, 'No truck / not sure'), ...trucks.map((t) => el('option', { value: t.id }, t.plate_no))]);
  const origin = el('input', { required: true, placeholder: 'e.g. Jinja' });
  const destination = el('input', { required: true, placeholder: 'e.g. Kampala' });
  const cargo = el('input', { placeholder: 'What are you hauling' });
  const rate = el('input', { type: 'number', step: '0.01', placeholder: 'UGX (if agreed already)' });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      try {
        await onSubmit({ truck_id: truckSel.value ? Number(truckSel.value) : null, origin: origin.value, destination: destination.value, cargo: cargo.value || null, rate: rate.value ? Number(rate.value) : null });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Log a load I found myself'),
    el('div', { class: 'field' }, [el('label', {}, 'Truck'), truckSel]),
    el('div', { class: 'form-row' }, [
      el('div', { class: 'field' }, [el('label', {}, 'Origin'), origin]),
      el('div', { class: 'field' }, [el('label', {}, 'Destination'), destination]),
    ]),
    el('div', { class: 'field' }, [el('label', {}, 'Cargo'), cargo]),
    el('div', { class: 'field' }, [el('label', {}, 'Rate (UGX)'), rate]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Save load')]),
  ]);
}

async function renderLoadsTab(container) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const [{ loads }, { trucks }] = await Promise.all([api.get('/api/fleet/loads'), api.get('/api/fleet/trucks')]);
  clear(container);
  container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
    el('button', {
      class: 'btn btn-accent btn-sm',
      onclick: () => {
        const form = loadForm(trucks, async (payload) => { await api.post('/api/fleet/loads', payload); close(); toast('Load saved', 'success'); renderLoadsTab(container); });
        const close = openModal(form);
      },
    }, '+ I found my own load')));
  const rows = loads.map((l) => el('tr', {}, [
    el('td', {}, fmtDate(l.load_date)), el('td', {}, `${l.origin} → ${l.destination}`), el('td', {}, l.cargo || '—'),
    el('td', { class: 'mono' }, l.rate ? fmtMoney(l.rate) : '—'), el('td', {}, l.self_sourced ? 'Self' : 'Dispatch'), el('td', {}, badge(l.status)),
  ]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Route', 'Cargo', 'Rate', 'Source', 'Status'].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 6 }, 'No loads yet.'))),
  ]))));
}

// ---------------- Report Issue ----------------
async function attachIssuePhoto(issueId, photoInput) {
  const file = photoInput.files[0];
  if (!file) return;
  try {
    const base64 = await blobToBase64(file);
    await api.post('/api/documents', { venture: 'fleet', ref_table: 'fleet_issues', ref_id: issueId, file_name: file.name, mime_type: file.type, file_base64: base64 });
  } catch (err) {
    toast('Report sent, but the photo failed to attach: ' + err.message, 'error');
  }
  photoInput.value = '';
}

async function renderIssueTab(container, trucks) {
  clear(container);
  const truckSel = el('select', {}, [el('option', { value: '' }, 'Not truck-specific'), ...trucks.map((t) => el('option', { value: t.id }, t.plate_no))]);
  const message = el('textarea', { rows: 4, placeholder: 'Describe the issue…' });
  const photoInput = el('input', { type: 'file', accept: 'image/*', capture: 'environment' });
  const sendTextBtn = el('button', { class: 'btn btn-primary', type: 'button' }, 'Send text report');

  let mediaRecorder = null, chunks = [], stream = null, timerInterval = null, seconds = 0, maxTimeout = null;
  const timerLabel = el('span', {}, '0:00');
  const recordBtn = el('button', { class: 'btn btn-danger record-btn', type: 'button' }, [el('span', { class: 'dot' }), 'Record voice note']);
  const status = el('div', { class: 'hint-text' }, 'Or record a voice note (max 3 minutes) if it\'s easier than typing.');

  async function startRecording() {
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      toast('Could not access the microphone', 'error');
      return;
    }
    chunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
    mediaRecorder.onstop = async () => {
      clearInterval(timerInterval); clearTimeout(maxTimeout);
      stream.getTracks().forEach((t) => t.stop());
      recordBtn.classList.remove('recording');
      recordBtn.replaceChildren(el('span', { class: 'dot' }), 'Record voice note');
      if (chunks.length === 0) return;
      const blob = new Blob(chunks, { type: 'audio/webm' });
      const base64 = await blobToBase64(blob);
      try {
        const { id } = await api.post('/api/fleet/issues', { kind: 'voice', truck_id: truckSel.value ? Number(truckSel.value) : null, voice_base64: base64, voice_seconds: seconds, mime_type: 'audio/webm' });
        if (photoInput.files[0]) await attachIssuePhoto(id, photoInput);
        toast('Voice note sent', 'success');
        renderMyIssues(myIssuesBox);
      } catch (err) { toast(err.message, 'error'); }
    };
    mediaRecorder.start();
    seconds = 0;
    recordBtn.classList.add('recording');
    recordBtn.replaceChildren(el('span', { class: 'dot' }), 'Stop (', timerLabel, ')');
    timerInterval = setInterval(() => { seconds += 1; timerLabel.textContent = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`; }, 1000);
    maxTimeout = setTimeout(() => { if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop(); }, 180000);
  }

  recordBtn.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state === 'recording') { mediaRecorder.stop(); }
    else { startRecording(); }
  });

  sendTextBtn.addEventListener('click', async () => {
    if (!message.value.trim()) { toast('Write a short message first', 'error'); return; }
    try {
      const { id } = await api.post('/api/fleet/issues', { kind: 'text', truck_id: truckSel.value ? Number(truckSel.value) : null, message: message.value.trim() });
      if (photoInput.files[0]) await attachIssuePhoto(id, photoInput);
      message.value = '';
      toast('Report sent to Admin/Dispatch', 'success');
      renderMyIssues(myIssuesBox);
    } catch (err) { toast(err.message, 'error'); }
  });

  const myIssuesBox = el('div', {});

  container.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, 'Report a truck issue'),
    el('div', { class: 'field' }, [el('label', {}, 'Truck (optional)'), truckSel]),
    el('div', { class: 'field' }, [el('label', {}, 'Message'), message]),
    el('div', { class: 'field' }, [el('label', {}, 'Attach a photo (optional)'), photoInput]),
    sendTextBtn,
    el('div', { style: { height: '18px' } }),
    status,
    recordBtn,
  ]));
  container.appendChild(myIssuesBox);

  await renderMyIssues(myIssuesBox);
}

async function renderMyIssues(container) {
  clear(container);
  const [{ issues }, { documents }] = await Promise.all([
    api.get('/api/fleet/issues'),
    api.get('/api/documents?ref_table=fleet_issues'),
  ]);
  if (!issues.length) return;
  const photoByIssue = {};
  documents.forEach((d) => { photoByIssue[d.ref_id] = d; });
  const rows = issues.map((i) => el('tr', {}, [
    el('td', {}, fmtDate(i.created_at)),
    el('td', {}, i.kind === 'voice' ? `Voice note (${Math.round(i.voice_seconds || 0)}s)` : i.message),
    el('td', {}, photoByIssue[i.id] ? el('a', { href: fileUrl(photoByIssue[i.id].id), target: '_blank' }, 'View photo') : '—'),
    el('td', {}, badge(i.status)),
  ]));
  container.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, 'My reports'),
    el('div', { class: 'table-wrap' }, el('table', {}, [
      el('thead', {}, el('tr', {}, ['Date', 'Issue', 'Photo', 'Status'].map((h) => el('th', {}, h)))),
      el('tbody', {}, rows),
    ])),
  ]));
}

// ---------------- Expense Requests ----------------
function expenseForm(onSubmit) {
  const category = el('select', {}, ['mechanical_repair', 'fuel', 'toll', 'tyres', 'other'].map((c) => el('option', { value: c }, c.replace(/_/g, ' '))));
  const amount = el('input', { type: 'number', step: '0.01', required: true, placeholder: 'UGX' });
  const description = el('textarea', { rows: 3, placeholder: 'What happened / what it\'s for' });
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      try { await onSubmit({ category: category.value, amount: Number(amount.value), description: description.value || null }); }
      catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Submit expense request'),
    el('div', { class: 'field' }, [el('label', {}, 'Category'), category]),
    el('div', { class: 'field' }, [el('label', {}, 'Amount (UGX)'), amount]),
    el('div', { class: 'field' }, [el('label', {}, 'Description'), description]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Submit')]),
  ]);
}

async function attachReceipt(requestId) {
  const fileInput = el('input', { type: 'file', accept: 'image/*,application/pdf' });
  const errorBox = el('div', { class: 'error-text' });
  const form = el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      const file = fileInput.files[0];
      if (!file) { errorBox.textContent = 'Choose a file first'; return; }
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          await api.post('/api/documents', { venture: 'fleet', ref_table: 'expense_requests', ref_id: requestId, file_name: file.name, mime_type: file.type, file_base64: reader.result });
          toast('Receipt attached', 'success');
          close();
        } catch (err) { errorBox.textContent = err.message; }
      };
      reader.readAsDataURL(file);
    },
  }, [
    el('h3', {}, 'Attach receipt'),
    el('div', { class: 'field' }, [el('label', {}, 'File'), fileInput]),
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Upload')]),
  ]);
  const close = openModal(form);
}

async function renderExpensesTab(container) {
  clear(container);
  container.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  const { requests } = await api.get('/api/fleet/expense-requests');
  clear(container);
  container.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
    el('button', {
      class: 'btn btn-accent btn-sm',
      onclick: () => {
        const form = expenseForm(async (payload) => { await api.post('/api/fleet/expense-requests', payload); close(); toast('Submitted', 'success'); renderExpensesTab(container); });
        const close = openModal(form);
      },
    }, '+ New request')));

  const rows = requests.map((r) => el('tr', {}, [
    el('td', {}, fmtDate(r.created_at)), el('td', {}, r.category.replace(/_/g, ' ')), el('td', { class: 'mono' }, fmtMoney(r.amount)),
    el('td', {}, r.description || '—'), el('td', {}, badge(r.status)),
    el('td', {}, r.status === 'accepted' ? el('div', { style: { display: 'flex', gap: '6px' } }, [
      el('button', { class: 'btn btn-accent btn-sm', onclick: async () => { await api.patch(`/api/fleet/expense-requests/${r.id}`, { status: 'settled' }); toast('Marked settled', 'success'); renderExpensesTab(container); } }, 'Mark settled'),
      el('button', { class: 'btn btn-ghost btn-sm', onclick: () => attachReceipt(r.id) }, 'Attach receipt'),
    ]) : (r.status === 'settled' ? el('button', { class: 'btn btn-ghost btn-sm', onclick: () => attachReceipt(r.id) }, 'Attach receipt') : '—')),
  ]));
  container.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['Date', 'Category', 'Amount', 'Notes', 'Status', ''].map((h) => el('th', {}, h)))),
    el('tbody', {}, rows.length ? rows : el('tr', { class: 'empty-row' }, el('td', { colspan: 6 }, 'No requests yet.'))),
  ]))));
}

export async function renderDriverHome(content, user) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, `Hi, ${user.name.split(' ')[0]}`), el('p', {}, 'Your loads, issue reports, and expense requests.')]),
  ]));

  const { trucks } = await api.get('/api/fleet/trucks');
  const tabsDef = [
    ['loads', 'My loads', (c) => renderLoadsTab(c)],
    ['issue', 'Report issue', (c) => renderIssueTab(c, trucks)],
    ['expenses', 'Expense requests', (c) => renderExpensesTab(c)],
  ];
  const body = el('div', {});
  const tabsBar = el('div', { class: 'tabs' });
  function activate(key) {
    tabsBar.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.key === key));
    clear(body);
    tabsDef.find(([k]) => k === key)[2](body);
  }
  tabsDef.forEach(([key, label]) => tabsBar.appendChild(el('div', { class: 'tab', 'data-key': key, onclick: () => activate(key) }, label)));
  content.appendChild(tabsBar);
  content.appendChild(body);
  activate('loads');
}
