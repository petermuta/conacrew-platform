import { el, clear, fmtMoney } from '../dom.js';
import { api } from '../api.js';

function tile(label, value, cls = '') {
  return el('div', { class: 'stat-tile' }, [
    el('div', { class: 'label' }, label),
    el('div', { class: `value ${cls}` }, value),
  ]);
}

async function renderAdminDispatch(content, user) {
  const [summary, issues, requests] = await Promise.all([
    api.get('/api/ledger/summary'),
    api.get('/api/fleet/issues'),
    api.get('/api/fleet/expense-requests'),
  ]);
  const openIssues = issues.issues.filter((i) => i.status === 'open').length;
  const pendingRequests = requests.requests.filter((r) => r.status === 'pending').length;

  const byVenture = {};
  for (const v of summary.by_venture) byVenture[v.venture] = v;
  const label = { fleet: 'Fleet', sugarcane: 'Sugarcane', passion_fruit: 'Passion Fruit', overhead: 'Overhead' };

  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [
      el('h2', {}, `Welcome, ${user.name.split(' ')[0]}`),
      el('p', {}, 'Company-wide snapshot across all three ventures.'),
    ]),
  ]));

  content.appendChild(el('div', { class: 'grid grid-3' }, [
    tile('Total revenue', fmtMoney(summary.totals.revenue)),
    tile('Total expense', fmtMoney(summary.totals.expense)),
    tile('Net position', fmtMoney(summary.totals.net), summary.totals.net >= 0 ? 'positive' : 'negative'),
  ]));

  content.appendChild(el('div', { class: 'card' }, [
    el('h3', {}, 'By venture'),
    el('div', { class: 'table-wrap' }, [
      el('table', {}, [
        el('thead', {}, el('tr', {}, [el('th', {}, 'Venture'), el('th', {}, 'Revenue'), el('th', {}, 'Expense'), el('th', {}, 'Net')])),
        el('tbody', {}, ['fleet', 'sugarcane', 'passion_fruit', 'overhead'].map((v) => {
          const row = byVenture[v] || { revenue: 0, expense: 0 };
          const net = row.revenue - row.expense;
          return el('tr', {}, [
            el('td', {}, label[v]),
            el('td', { class: 'mono' }, fmtMoney(row.revenue)),
            el('td', { class: 'mono' }, fmtMoney(row.expense)),
            el('td', { class: `mono ${net >= 0 ? '' : 'error-text'}` }, fmtMoney(net)),
          ]);
        })),
      ]),
    ]),
  ]));

  content.appendChild(el('div', { class: 'grid grid-2' }, [
    tile('Open fleet issues', String(openIssues), openIssues > 0 ? 'negative' : ''),
    tile('Pending expense requests', String(pendingRequests), pendingRequests > 0 ? 'negative' : ''),
  ]));
}

async function renderSugarcaneManager(content, user) {
  const [deals, sales] = await Promise.all([
    api.get('/api/sugarcane/deals'),
    api.get('/api/sugarcane/sales'),
  ]);
  const openDeals = deals.deals.filter((d) => d.status === 'open').length;
  const totalTonnage = sales.sales.reduce((s, r) => s + r.tonnage, 0);
  const totalRevenue = sales.sales.reduce((s, r) => s + r.tonnage * r.rate_per_ton, 0);

  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [
      el('h2', {}, `Welcome, ${user.name.split(' ')[0]}`),
      el('p', {}, 'Your sugarcane operation at a glance.'),
    ]),
  ]));
  content.appendChild(el('div', { class: 'grid grid-3' }, [
    tile('Open deals', String(openDeals)),
    tile('Tonnage sold', `${totalTonnage.toLocaleString()} t`),
    tile('Sales revenue', fmtMoney(totalRevenue)),
  ]));
  content.appendChild(el('div', { class: 'card' }, el('a', { href: '#/sugarcane', class: 'btn btn-primary' }, 'Go to Sugarcane')));
}

async function renderPassionFruitManager(content, user) {
  const [summary, harvests, sales] = await Promise.all([
    api.get('/api/passionfruit/summary'),
    api.get('/api/passionfruit/harvests'),
    api.get('/api/passionfruit/sales'),
  ]);
  const totalHarvested = harvests.harvests.reduce((s, r) => s + r.kg, 0);
  const totalSalesRevenue = sales.sales.reduce((s, r) => s + r.kg * r.rate_per_kg, 0);

  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [
      el('h2', {}, `Welcome, ${user.name.split(' ')[0]}`),
      el('p', {}, 'Your passion fruit farm at a glance.'),
    ]),
  ]));
  content.appendChild(el('div', { class: 'grid grid-3' }, [
    tile('Available inventory', `${summary.available_kg.toLocaleString()} kg`),
    tile('Total harvested', `${totalHarvested.toLocaleString()} kg`),
    tile('Sales revenue', fmtMoney(totalSalesRevenue)),
  ]));
  content.appendChild(el('div', { class: 'card' }, el('a', { href: '#/passionfruit', class: 'btn btn-primary' }, 'Go to Passion Fruit')));
}

export async function renderDashboard(content, user) {
  content.appendChild(el('p', { class: 'muted' }, 'Loading…'));
  if (user.role === 'admin' || user.role === 'dispatcher') return renderAdminDispatch(content, user);
  if (user.role === 'sugarcane_manager') return renderSugarcaneManager(content, user);
  if (user.role === 'passion_fruit_manager') return renderPassionFruitManager(content, user);
}
