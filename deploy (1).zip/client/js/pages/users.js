import { el, clear, fmtDate, badgeAs, toast, openModal } from '../dom.js';
import { api } from '../api.js';

const ROLE_LABEL = {
  admin: 'Admin', dispatcher: 'Dispatcher', sugarcane_manager: 'Sugarcane Manager',
  passion_fruit_manager: 'Passion Fruit Manager', driver: 'Driver',
};

function userForm(operations, onSubmit) {
  const name = el('input', { required: true, placeholder: 'Full name' });
  const email = el('input', { type: 'email', required: true, placeholder: 'email@example.com' });
  const password = el('input', { type: 'password', required: true, placeholder: 'Temporary password', minlength: 8 });
  const role = el('select', {}, Object.entries(ROLE_LABEL).map(([v, l]) => el('option', { value: v }, l)));
  const opSel = el('select', {}, operations.map((o) => el('option', { value: o.id }, o.name)));
  const opWrap = el('div', { class: 'field' }, [el('label', {}, 'Sugarcane operation'), opSel]);
  function sync() { opWrap.style.display = role.value === 'sugarcane_manager' ? '' : 'none'; }
  role.addEventListener('change', sync); sync();
  const errorBox = el('div', { class: 'error-text' });
  return el('form', {
    onsubmit: async (e) => {
      e.preventDefault(); errorBox.textContent = '';
      try {
        await onSubmit({
          name: name.value, email: email.value, password: password.value, role: role.value,
          operation_id: role.value === 'sugarcane_manager' ? Number(opSel.value) : undefined,
        });
      } catch (err) { errorBox.textContent = err.message; }
    },
  }, [
    el('h3', {}, 'Add a user'),
    el('div', { class: 'field' }, [el('label', {}, 'Name'), name]),
    el('div', { class: 'field' }, [el('label', {}, 'Email'), email]),
    el('div', { class: 'field' }, [el('label', {}, 'Temporary password'), password]),
    el('div', { class: 'field' }, [el('label', {}, 'Role'), role]),
    opWrap,
    errorBox,
    el('div', { class: 'modal-actions' }, [el('button', { class: 'btn btn-primary', type: 'submit' }, 'Create user')]),
  ]);
}

export async function renderUsers(content) {
  clear(content);
  content.appendChild(el('div', { class: 'page-header' }, [
    el('div', {}, [el('h2', {}, 'Users'), el('p', {}, 'Everyone with a login, and what they can see.')]),
  ]));

  const body = el('div', {});
  content.appendChild(body);

  async function load() {
    clear(body);
    body.appendChild(el('p', { class: 'muted' }, 'Loading…'));
    const [{ users }, { operations }] = await Promise.all([api.get('/api/users'), api.get('/api/sugarcane/operations')]);
    clear(body);

    body.appendChild(el('div', { style: { display: 'flex', justifyContent: 'flex-end', marginBottom: '12px' } },
      el('button', {
        class: 'btn btn-accent btn-sm',
        onclick: () => {
          const form = userForm(operations, async (payload) => {
            await api.post('/api/users', payload);
            close(); toast('User created', 'success'); load();
          });
          const close = openModal(form);
        },
      }, '+ Add user')));

    const rows = users.map((u) => el('tr', {}, [
      el('td', {}, u.name),
      el('td', {}, u.email),
      el('td', {}, ROLE_LABEL[u.role] + (u.operation_name ? ` (${u.operation_name})` : '')),
      el('td', {}, fmtDate(u.created_at)),
      el('td', {}, u.active ? badgeAs('resolved', 'Active') : badgeAs('declined', 'Inactive')),
      el('td', {}, el('button', {
        class: 'btn btn-ghost btn-sm',
        onclick: async () => {
          await api.patch(`/api/users/${u.id}`, { active: !u.active });
          toast(u.active ? 'User deactivated' : 'User reactivated', 'success');
          load();
        },
      }, u.active ? 'Deactivate' : 'Reactivate')),
    ]));
    body.appendChild(el('div', { class: 'card' }, el('div', { class: 'table-wrap' }, el('table', {}, [
      el('thead', {}, el('tr', {}, ['Name', 'Email', 'Role', 'Added', 'Active', ''].map((h) => el('th', {}, h)))),
      el('tbody', {}, rows),
    ]))));
  }

  await load();
}
