import { api } from './api.js';
import { el } from './dom.js';

const FLAG_KEY = 'conacrew_loc_enabled';
const REPORT_INTERVAL_MS = 60 * 1000; // report at most once a minute
let lastSent = 0;
let watchId = null;

function reportPosition(pos) {
  const now = Date.now();
  if (now - lastSent < REPORT_INTERVAL_MS) return;
  lastSent = now;
  api.post('/api/locations', { lat: pos.coords.latitude, lng: pos.coords.longitude }).catch(() => {});
}

function beginWatch() {
  if (watchId !== null || !navigator.geolocation) return;
  watchId = navigator.geolocation.watchPosition(reportPosition, () => {}, {
    enableHighAccuracy: false,
    maximumAge: 30000,
    timeout: 20000,
  });
}

export function startLocationTracking() {
  if (localStorage.getItem(FLAG_KEY) === '1') {
    beginWatch();
    return;
  }
  showEnablePrompt();
}

function showEnablePrompt() {
  if (document.getElementById('loc-prompt')) return;
  const banner = el('div', {
    id: 'loc-prompt',
    style: {
      position: 'fixed', bottom: '16px', right: '16px', left: '16px', maxWidth: '420px',
      marginLeft: 'auto', background: '#132A46', color: 'white', padding: '14px 16px',
      borderRadius: '10px', boxShadow: '0 6px 20px rgba(0,0,0,0.25)', zIndex: 200,
      display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap',
    },
  }, [
    el('div', { style: { flex: '1', fontSize: '13.5px', minWidth: '180px' } },
      'This app records your location while you\'re logged in, for fleet/field visibility.'),
    el('button', {
      class: 'btn btn-accent btn-sm',
      onclick: () => {
        localStorage.setItem(FLAG_KEY, '1');
        banner.remove();
        beginWatch();
      },
    }, 'Enable'),
  ]);
  document.body.appendChild(banner);
}
